--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: changes; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE changes (
    id integer NOT NULL,
    added_by character varying(255),
    content text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer,
    subject text
);


ALTER TABLE public.changes OWNER TO unix_web;

--
-- Name: changes_id_seq; Type: SEQUENCE; Schema: public; Owner: unix_web
--

CREATE SEQUENCE changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.changes_id_seq OWNER TO unix_web;

--
-- Name: changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: unix_web
--

ALTER SEQUENCE changes_id_seq OWNED BY changes.id;


--
-- Name: changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: unix_web
--

SELECT pg_catalog.setval('changes_id_seq', 61, true);


--
-- Name: cpus; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE cpus (
    id integer NOT NULL,
    processor character varying(255),
    model character varying(255),
    core_count integer,
    base_speed_mhz integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.cpus OWNER TO unix_web;

--
-- Name: cpus_id_seq; Type: SEQUENCE; Schema: public; Owner: unix_web
--

CREATE SEQUENCE cpus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.cpus_id_seq OWNER TO unix_web;

--
-- Name: cpus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: unix_web
--

ALTER SEQUENCE cpus_id_seq OWNED BY cpus.id;


--
-- Name: cpus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: unix_web
--

SELECT pg_catalog.setval('cpus_id_seq', 1, true);


--
-- Name: datacenters; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE datacenters (
    id integer NOT NULL,
    name character varying(255),
    address character varying(255),
    postcode character varying(255),
    comment character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.datacenters OWNER TO unix_web;

--
-- Name: datacenters_id_seq; Type: SEQUENCE; Schema: public; Owner: unix_web
--

CREATE SEQUENCE datacenters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.datacenters_id_seq OWNER TO unix_web;

--
-- Name: datacenters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: unix_web
--

ALTER SEQUENCE datacenters_id_seq OWNED BY datacenters.id;


--
-- Name: datacenters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: unix_web
--

SELECT pg_catalog.setval('datacenters_id_seq', 5, true);


--
-- Name: operating_systems; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE operating_systems (
    id integer NOT NULL,
    name character varying(255),
    version character varying(255),
    release character varying(255),
    comment character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.operating_systems OWNER TO unix_web;

--
-- Name: operating_systems_id_seq; Type: SEQUENCE; Schema: public; Owner: unix_web
--

CREATE SEQUENCE operating_systems_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.operating_systems_id_seq OWNER TO unix_web;

--
-- Name: operating_systems_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: unix_web
--

ALTER SEQUENCE operating_systems_id_seq OWNED BY operating_systems.id;


--
-- Name: operating_systems_id_seq; Type: SEQUENCE SET; Schema: public; Owner: unix_web
--

SELECT pg_catalog.setval('operating_systems_id_seq', 1, true);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE projects (
    id integer NOT NULL,
    name character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    comment character varying(255)
);


ALTER TABLE public.projects OWNER TO unix_web;

--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: unix_web
--

CREATE SEQUENCE projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.projects_id_seq OWNER TO unix_web;

--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: unix_web
--

ALTER SEQUENCE projects_id_seq OWNED BY projects.id;


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: unix_web
--

SELECT pg_catalog.setval('projects_id_seq', 28, true);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO unix_web;

--
-- Name: server_models; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE server_models (
    id integer NOT NULL,
    name character varying(255),
    manufacturer character varying(255),
    uheight integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    power integer,
    power_sockets integer,
    heat_dissipation integer
);


ALTER TABLE public.server_models OWNER TO unix_web;

--
-- Name: server_models_id_seq; Type: SEQUENCE; Schema: public; Owner: unix_web
--

CREATE SEQUENCE server_models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.server_models_id_seq OWNER TO unix_web;

--
-- Name: server_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: unix_web
--

ALTER SEQUENCE server_models_id_seq OWNED BY server_models.id;


--
-- Name: server_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: unix_web
--

SELECT pg_catalog.setval('server_models_id_seq', 40, true);


--
-- Name: server_racks; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE server_racks (
    id integer NOT NULL,
    name character varying(255),
    datacenter_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.server_racks OWNER TO unix_web;

--
-- Name: server_racks_id_seq; Type: SEQUENCE; Schema: public; Owner: unix_web
--

CREATE SEQUENCE server_racks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.server_racks_id_seq OWNER TO unix_web;

--
-- Name: server_racks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: unix_web
--

ALTER SEQUENCE server_racks_id_seq OWNED BY server_racks.id;


--
-- Name: server_racks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: unix_web
--

SELECT pg_catalog.setval('server_racks_id_seq', 99, true);


--
-- Name: servers; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE servers (
    id integer NOT NULL,
    name character varying(255),
    virtual boolean,
    parent_id integer,
    datacenter_id integer,
    serial character varying(255),
    server_rack_id integer,
    server_model_id integer,
    cpu_number integer,
    cpu_id integer,
    ram integer,
    environment character varying(255),
    responsible_team_id integer,
    project_id integer,
    oob_address character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    usage character varying(255),
    operating_system character varying(255),
    added_by integer,
    edited_by integer,
    cpu_type character varying(255),
    decommissioned boolean DEFAULT false,
    decommissioned_date date,
    decommissioned_by character varying(255),
    powered_off boolean DEFAULT false,
    powered_off_date date
);


ALTER TABLE public.servers OWNER TO unix_web;

--
-- Name: servers_id_seq; Type: SEQUENCE; Schema: public; Owner: unix_web
--

CREATE SEQUENCE servers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.servers_id_seq OWNER TO unix_web;

--
-- Name: servers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: unix_web
--

ALTER SEQUENCE servers_id_seq OWNED BY servers.id;


--
-- Name: servers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: unix_web
--

SELECT pg_catalog.setval('servers_id_seq', 476, true);


--
-- Name: users; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    name character varying(255),
    email character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    password_digest character varying(255),
    remember_token character varying(255),
    admin boolean DEFAULT false
);


ALTER TABLE public.users OWNER TO unix_web;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: unix_web
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO unix_web;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: unix_web
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: unix_web
--

SELECT pg_catalog.setval('users_id_seq', 6, true);


--
-- Name: vclusters; Type: TABLE; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE TABLE vclusters (
    id integer NOT NULL,
    name character varying(255),
    comment text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.vclusters OWNER TO unix_web;

--
-- Name: vclusters_id_seq; Type: SEQUENCE; Schema: public; Owner: unix_web
--

CREATE SEQUENCE vclusters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.vclusters_id_seq OWNER TO unix_web;

--
-- Name: vclusters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: unix_web
--

ALTER SEQUENCE vclusters_id_seq OWNED BY vclusters.id;


--
-- Name: vclusters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: unix_web
--

SELECT pg_catalog.setval('vclusters_id_seq', 1, false);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: unix_web
--

ALTER TABLE ONLY changes ALTER COLUMN id SET DEFAULT nextval('changes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: unix_web
--

ALTER TABLE ONLY cpus ALTER COLUMN id SET DEFAULT nextval('cpus_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: unix_web
--

ALTER TABLE ONLY datacenters ALTER COLUMN id SET DEFAULT nextval('datacenters_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: unix_web
--

ALTER TABLE ONLY operating_systems ALTER COLUMN id SET DEFAULT nextval('operating_systems_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: unix_web
--

ALTER TABLE ONLY projects ALTER COLUMN id SET DEFAULT nextval('projects_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: unix_web
--

ALTER TABLE ONLY server_models ALTER COLUMN id SET DEFAULT nextval('server_models_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: unix_web
--

ALTER TABLE ONLY server_racks ALTER COLUMN id SET DEFAULT nextval('server_racks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: unix_web
--

ALTER TABLE ONLY servers ALTER COLUMN id SET DEFAULT nextval('servers_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: unix_web
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: unix_web
--

ALTER TABLE ONLY vclusters ALTER COLUMN id SET DEFAULT nextval('vclusters_id_seq'::regclass);


--
-- Data for Name: changes; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY changes (id, added_by, content, created_at, updated_at, user_id, subject) FROM stdin;
18	\N	Some stuff happened.	2012-11-14 17:25:58.075422	2012-11-14 17:25:58.075422	\N	First Change
19	\N	dvzz601\r\ndvzz601\r\ndvzz601\r\ndvzz601	2012-11-15 11:16:50.290467	2012-11-15 11:16:50.290467	\N	Some test
20	\N	not in content	2012-11-15 13:30:08.22623	2012-11-15 13:30:08.22623	\N	foo in subject
21	\N	Foo in content	2012-11-15 13:30:24.674347	2012-11-15 13:30:24.674347	\N	not in subject
22	\N	not in content	2012-11-15 13:30:39.129001	2012-11-15 13:30:39.129001	\N	not in subject
23	\N		2012-11-15 13:43:38.114389	2012-11-15 13:43:38.114389	\N	another foo in subject
24	\N	foo in content at front	2012-11-15 13:43:56.421018	2012-11-15 13:43:56.421018	\N	not in suject
26	\N	user added?	2012-11-15 13:54:53.219622	2012-11-15 13:54:53.219622	1	test
27	\N	user added?	2012-11-15 14:04:30.168832	2012-11-15 14:04:30.168832	1	test
28	\N	user added?	2012-11-15 14:06:06.822488	2012-11-15 14:06:06.822488	1	test
29	\N	Find foo	2012-11-15 14:15:55.609409	2012-11-15 14:15:55.609409	1	More stuff
47	\N	dvzz601\r\ndvzz603\r\n	2012-11-15 14:57:08.52435	2012-11-15 14:57:08.52435	1	test
58	\N	Customer Readiness application servers installed, ip address 10.102.1.123 for Betty Swollocks.	2012-11-16 12:31:07.112918	2012-11-16 12:31:07.112918	1	Install new server crap401
59	\N	150 gb volume added to crap301	2012-11-16 12:38:40.021784	2012-11-16 12:38:40.021784	1	added volume tp crap301
60	\N	Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.	2012-11-16 14:48:25.251313	2012-11-16 14:48:25.251313	1	remove crap501
61	\N	Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.	2012-11-16 14:51:15.163549	2012-11-16 14:51:15.163549	1	Long content
\.


--
-- Data for Name: cpus; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY cpus (id, processor, model, core_count, base_speed_mhz, created_at, updated_at) FROM stdin;
1	Dual-Core AMD Opteron	8220	2	2800	2012-10-22 17:04:01.244502	2012-10-22 17:04:01.244502
\.


--
-- Data for Name: datacenters; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY datacenters (id, name, address, postcode, comment, created_at, updated_at) FROM stdin;
1	Dunstable-1	\N	\N	\N	2012-10-22 13:52:25.982596	2012-10-22 13:52:25.982596
2	Debden	\N	\N	\N	2012-11-26 11:16:25.789007	2012-11-26 11:16:25.789007
3	Harrogate	\N	\N	\N	2012-11-27 12:10:34.600334	2012-11-27 12:10:34.600334
4	Dunstable-2	\N	\N	\N	2012-11-27 12:10:54.316719	2012-11-27 12:10:54.316719
5	Pudsey	\N	\N	\N	2012-11-27 12:12:09.39364	2012-11-27 12:12:09.39364
\.


--
-- Data for Name: operating_systems; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY operating_systems (id, name, version, release, comment, created_at, updated_at) FROM stdin;
1	Solaris	10	\N	\N	2012-10-22 10:09:35.040735	2012-10-22 10:09:35.040735
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY projects (id, name, created_at, updated_at, comment) FROM stdin;
1	ECS	2012-10-23 10:15:04.038979	2012-10-23 10:15:04.038979	\N
2	BPSL	2012-10-25 10:38:39.729481	2012-10-25 10:38:39.729481	BACS Payments Solutions Limited
11	FPS	2012-10-25 10:45:37.366389	2012-10-25 10:45:37.366389	Faster Payments
14	BACS	2012-10-26 11:52:24.890077	2012-10-26 11:52:24.890077	
15	AMS	2012-10-26 11:52:29.653982	2012-10-26 11:52:29.653982	
16	BGC	2012-10-26 11:52:35.661534	2012-10-26 11:52:35.661534	
17	ETS/STS	2012-10-26 11:53:18.795391	2012-10-26 11:53:18.795391	
18	Opsware	2012-10-26 11:53:40.926184	2012-10-26 11:53:40.926184	
19	BACSTEL	2012-10-26 11:53:50.362638	2012-10-26 11:53:50.362638	
20	Infrastructure	2012-11-23 10:03:35.668671	2012-11-23 10:03:35.668671	Infrastructure Items
21	FPMS	2012-11-26 14:24:11.099016	2012-11-26 14:24:11.099016	Single pipe, etc.
22	Mobile Payments	2012-11-26 15:57:26.238358	2012-11-26 15:57:26.238358	
23	IPS	2012-11-26 17:12:21.938508	2012-11-26 17:12:21.938508	Immediate Payments
24	CM	2012-11-27 12:18:59.162452	2012-11-27 12:18:59.162452	Config Management
25	DCM LSR	2012-12-03 10:14:10.893238	2012-12-03 10:14:10.893238	Datacenter Migration Something Something Something
26	SHARED	2012-12-03 17:31:58.014505	2012-12-03 17:31:58.014505	Shared components, e.g. proxy servers.
13	DEPS	2012-10-26 11:49:41.052676	2012-12-05 14:11:45.288003	DWP EP System
27	AP	2012-12-20 11:30:28.564696	2012-12-20 11:30:28.564696	Alternate Payments
28	Swift	2012-12-21 12:54:56.949314	2012-12-21 12:54:56.949314	Swift
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY schema_migrations (version) FROM stdin;
20121016125520
20121016140723
20121016142642
20121017151216
20121018144822
20121019114724
20121022095725
20121022104435
20121022113303
20121022135814
20121022135848
20121022142932
20121022154314
20121022170127
20121023091413
20121023092117
20121023101139
20121023101906
20121024134610
20121113131950
20121114121326
20121114121521
20121114132836
20121122162034
20121123102311
20121123102623
20121123151018
20121126161758
20121129170443
20121130143535
20121207142303
20121207165624
20121210124153
20121227114027
\.


--
-- Data for Name: server_models; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY server_models (id, name, manufacturer, uheight, created_at, updated_at, power, power_sockets, heat_dissipation) FROM stdin;
4		\N	\N	2012-11-23 15:45:03.156188	2012-11-23 15:45:03.156188	\N	\N	\N
1	X4600	Oracle	4	2012-10-22 15:47:34.848658	2012-11-26 18:44:31.69554	1354	2	4620
12	ProLiant BL460c G7	HP	\N	2012-11-27 14:39:45.083021	2012-11-28 11:20:43.371563	325	\N	1110
2	BladeSystem c7000 Enclosure	HP	10	2012-11-23 15:00:17.156061	2012-11-28 13:52:54.773511	700	4	2390
9	BladeSystem c3000 Enclosure	HP	6	2012-11-26 17:15:46.272443	2012-11-28 13:53:05.319269	885	2	3020
14	V490	Oracle	5	2012-11-29 14:43:44.846206	2012-11-29 14:46:05.219892	1023	2	3491
7	X4440	Oracle	2	2012-11-26 11:23:15.304667	2012-11-29 14:53:13.536026	505	2	1723
15	X4140	Oracle	1	2012-11-29 16:22:47.544394	2012-11-29 16:26:20.075039	303	2	1034
8	T4-1	Oracle	2	2012-11-26 16:00:28.832969	2012-11-29 16:26:40.979071	762	2	2600
6	T2000	Oracle	2	2012-11-26 11:19:34.379721	2012-11-29 16:26:46.929542	320	2	1364
18	X4100	Oracle	1	2012-11-30 13:17:21.975635	2012-11-30 13:29:02.873427	285	2	972
17	X4200	Oracle	2	2012-11-30 13:08:57.458504	2012-11-30 13:32:36.37009	435	2	1485
21	M5000	Oracle	10	2012-11-30 15:01:38.53476	2012-11-30 15:18:51.046927	1516	4	7000
22	SFX4170M2	Oracle	2	2012-12-03 10:19:08.012696	2012-12-03 10:23:48.041133	375	2	1280
24	VMWare VM	\N	\N	2012-12-03 16:57:28.028473	2012-12-03 16:57:28.028473	\N	\N	\N
26	X2100	Oracle	1	2012-12-04 14:05:25.393352	2012-12-04 14:06:12.871502	216	2	737
3	ProLiant BL490c G6	HP	\N	2012-11-23 15:29:00.595247	2012-12-07 10:35:16.345764	370	\N	1262
13	ProLiant BL685c G6	HP	\N	2012-11-28 11:29:33.638048	2012-12-08 11:35:50.656465	600	\N	2046
36	Cisco UCS 5108	Cisco Systems Inc	6	2012-12-19 14:40:25.963389	2012-12-19 14:44:25.296307	\N	4	\N
38	V245	Oracle	2	2012-12-21 12:54:03.464057	2012-12-21 17:56:02.061478	443	\N	1513
23	ESX 4.1		0	2012-12-03 16:55:19.576127	2012-12-21 17:56:31.911854	\N	\N	\N
34	Netra T1 120	Oracle	1	2012-12-07 16:45:26.562818	2012-12-21 17:56:41.573414	\N	\N	\N
39	T5120	Oracle	1	2012-12-21 12:58:18.106175	2012-12-21 17:57:52.525604	328	\N	1119
37	V120	Oracle	1	2012-12-20 17:59:58.534934	2012-12-21 17:59:39.180479	70	\N	340
35	280R	Oracle	4	2012-12-07 16:47:32.507977	2012-12-21 18:00:50.27427	418	\N	1427
40	SAN boot image T5120		0	2012-12-21 13:00:17.151543	2012-12-21 18:01:09.316484	\N	\N	\N
25	Solaris Zone		0	2012-12-04 11:30:35.589474	2012-12-21 18:01:21.777692	0	\N	0
32	V240	Oracle	2	2012-12-07 16:40:57.356658	2012-12-21 18:02:26.836111	443	\N	1513
31	V440	Oracle	4	2012-12-07 14:03:39.366552	2012-12-21 18:04:21.881522	570	\N	1945
30	V480	Oracle	5	2012-12-07 13:48:18.874437	2012-12-21 18:05:17.534538	1023	\N	3491
11	V880	Oracle	17	2012-11-27 12:22:32.577068	2012-12-21 18:05:51.500865	1440	4	4778
\.


--
-- Data for Name: server_racks; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY server_racks (id, name, datacenter_id, created_at, updated_at) FROM stdin;
1	SVB002	1	2012-10-22 14:19:37.414486	2012-10-22 14:19:37.414486
2	SVD609	1	2012-11-23 13:42:04.439471	2012-11-23 13:42:04.439471
7	FPS1	2	2012-11-26 11:19:34.327148	2012-11-26 11:19:34.327148
8	SVA001	2	2012-11-26 11:23:15.259387	2012-11-26 11:23:15.259387
9	SVD004	1	2012-11-26 11:32:03.419831	2012-11-26 11:32:03.419831
12		\N	2012-11-26 14:18:02.504907	2012-11-26 14:18:02.504907
13	LA02	2	2012-11-26 16:00:28.821019	2012-11-26 16:00:28.821019
14	SVD017	1	2012-11-26 17:15:46.227353	2012-11-26 17:15:46.227353
15	4	1	2012-11-27 12:22:32.525093	2012-11-27 12:22:32.525093
16	9	1	2012-11-27 12:25:29.780349	2012-11-27 12:25:29.780349
17		\N	2012-11-27 14:17:39.559247	2012-11-27 14:17:39.559247
18		\N	2012-11-27 14:22:34.575612	2012-11-27 14:22:34.575612
19		\N	2012-11-27 14:22:44.050318	2012-11-27 14:22:44.050318
20		\N	2012-11-27 14:23:03.941184	2012-11-27 14:23:03.941184
21	FPS2	2	2012-11-27 14:26:37.786074	2012-11-27 14:26:37.786074
22	X8	1	2012-11-27 14:29:52.125164	2012-11-27 14:29:52.125164
23	SVB001	2	2012-11-28 10:45:19.845939	2012-11-28 10:45:19.845939
33	SVA005	1	2012-11-29 14:43:44.806791	2012-11-29 14:43:44.806791
34	SVD010	1	2012-11-29 14:57:34.566746	2012-11-29 14:57:34.566746
35	SVA017	1	2012-11-29 14:59:29.149124	2012-11-29 14:59:29.149124
36	SVD008	1	2012-11-29 15:09:11.801	2012-11-29 15:09:11.801
37	SVD001	1	2012-11-29 15:27:06.905326	2012-11-29 15:27:06.905326
38	SVA016	1	2012-11-29 15:28:43.026754	2012-11-29 15:28:43.026754
39	SVC001	1	2012-11-29 15:30:13.396466	2012-11-29 15:30:13.396466
40	SVA002	2	2012-11-29 17:42:35.122267	2012-11-29 17:42:35.122267
41	SVB002	2	2012-11-29 17:44:02.576797	2012-11-29 17:44:02.576797
42	SVD011	1	2012-11-29 17:45:34.868892	2012-11-29 17:45:34.868892
43	SVA018	1	2012-11-29 17:46:11.386331	2012-11-29 17:46:11.386331
44	SVA012	1	2012-11-30 14:52:59.270608	2012-11-30 14:52:59.270608
45		\N	2012-11-30 17:45:14.383696	2012-11-30 17:45:14.383696
46	POD/DH8	3	2012-12-03 10:19:07.991223	2012-12-03 10:19:07.991223
47	SVB005	2	2012-12-03 12:53:35.835797	2012-12-03 12:53:35.835797
48	SVB006	2	2012-12-03 12:57:44.662307	2012-12-03 12:57:44.662307
49	SVA015	1	2012-12-03 13:09:14.726632	2012-12-03 13:09:14.726632
50	SVA011	2	2012-12-03 17:34:33.332028	2012-12-03 17:34:33.332028
51	SVB011	2	2012-12-03 17:43:44.903829	2012-12-03 17:43:44.903829
52		\N	2012-12-04 11:57:13.055259	2012-12-04 11:57:13.055259
53	SVB008	1	2012-12-04 13:48:02.169357	2012-12-04 13:48:02.169357
54	SVB009	1	2012-12-04 13:51:06.380711	2012-12-04 13:51:06.380711
55	SVB012	1	2012-12-04 14:01:28.049684	2012-12-04 14:01:28.049684
56	SVB011	1	2012-12-04 14:03:31.464845	2012-12-04 14:03:31.464845
57	SVA008	1	2012-12-04 14:33:21.71596	2012-12-04 14:33:21.71596
58		\N	2012-12-04 15:06:31.413541	2012-12-04 15:06:31.413541
59		\N	2012-12-04 15:19:58.862939	2012-12-04 15:19:58.862939
60		\N	2012-12-04 15:20:45.013155	2012-12-04 15:20:45.013155
61		\N	2012-12-04 15:23:31.749413	2012-12-04 15:23:31.749413
62		\N	2012-12-04 15:24:24.857685	2012-12-04 15:24:24.857685
63	SVB014	1	2012-12-04 17:16:12.063351	2012-12-04 17:16:12.063351
64	SVE011	1	2012-12-06 13:46:46.446617	2012-12-06 14:15:17.621791
65	Q19	3	2012-12-07 11:17:23.067044	2012-12-07 11:17:23.067044
66	P5	5	2012-12-07 11:18:18.127181	2012-12-07 11:18:18.127181
67	V17	3	2012-12-07 11:41:56.018482	2012-12-07 11:41:56.018482
68		\N	2012-12-07 12:34:49.661532	2012-12-07 12:34:49.661532
69	3	1	2012-12-07 13:48:18.86798	2012-12-07 13:48:18.86798
70	12	1	2012-12-07 14:03:39.320652	2012-12-07 14:03:39.320652
71	5	1	2012-12-07 15:59:19.360282	2012-12-07 15:59:19.360282
72	1	2	2012-12-07 16:40:57.347001	2012-12-07 16:40:57.347001
73	1	1	2012-12-07 16:47:32.503426	2012-12-07 16:47:32.503426
74		\N	2012-12-08 11:44:19.915872	2012-12-08 11:44:19.915872
75	SVB019	1	2012-12-19 14:40:25.882463	2012-12-19 14:40:25.882463
76	G3	2	2012-12-20 17:59:58.527437	2012-12-20 17:59:58.527437
78	SVB015	2	2012-12-20 18:07:58.869102	2012-12-20 18:07:58.869102
79	SVA015	2	2012-12-20 18:08:50.562222	2012-12-20 18:08:50.562222
80	SVA023	1	2012-12-20 18:11:16.676207	2012-12-20 18:11:16.676207
81	SVE001	1	2012-12-20 18:12:12.5214	2012-12-20 18:12:12.5214
82	SVE002	1	2012-12-20 18:13:05.253263	2012-12-20 18:13:05.253263
83	SVB016	2	2012-12-21 11:22:53.039245	2012-12-21 11:22:53.039245
84	SVA016	2	2012-12-21 11:23:43.325644	2012-12-21 11:23:43.325644
85	SVC005	1	2012-12-21 11:24:37.428467	2012-12-21 11:24:37.428467
86	SVD005	1	2012-12-21 11:25:36.741127	2012-12-21 11:25:36.741127
87	SVC004	1	2012-12-21 11:26:18.916611	2012-12-21 11:26:18.916611
88	X9	1	2012-12-21 12:45:37.244869	2012-12-21 12:45:37.244869
89	10	1	2012-12-21 12:52:23.561837	2012-12-21 12:52:23.561837
90	SVA009	1	2012-12-21 13:01:58.330715	2012-12-21 13:01:58.330715
77	NB-1	1	2012-12-20 18:01:25.947896	2012-12-21 14:01:02.647474
91	SVA003	2	2012-12-21 14:06:15.449438	2012-12-21 14:06:15.449438
92	SVA004	2	2012-12-21 14:07:07.123187	2012-12-21 14:07:07.123187
93	SVA006	1	2012-12-21 14:11:41.017903	2012-12-21 14:11:41.017903
94	SVA007	1	2012-12-21 14:12:30.522781	2012-12-21 14:12:30.522781
95	SVA004	1	2012-12-21 15:42:17.428524	2012-12-21 15:42:17.428524
96	SVA003	1	2012-12-21 15:51:55.92559	2012-12-21 15:51:55.92559
97	SVA002	1	2012-12-21 15:54:38.853802	2012-12-21 15:54:38.853802
98	SVA006	2	2012-12-21 17:19:58.818933	2012-12-21 17:19:58.818933
99	SVA007	2	2012-12-21 17:20:31.436534	2012-12-21 17:20:31.436534
\.


--
-- Data for Name: servers; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY servers (id, name, virtual, parent_id, datacenter_id, serial, server_rack_id, server_model_id, cpu_number, cpu_id, ram, environment, responsible_team_id, project_id, oob_address, created_at, updated_at, usage, operating_system, added_by, edited_by, cpu_type, decommissioned, decommissioned_date, decommissioned_by, powered_off, powered_off_date) FROM stdin;
12	badb501	\N	10	1		9	4	\N	\N	\N	Dev	\N	2		2012-11-26 11:55:44.808468	2012-12-07 14:38:32.955084	DB	Solaris 10	1	\N		f	\N	\N	f	\N
36	spzz401	\N	3	1	CZJ00305MY	2	13	4	\N	128	CR	\N	21	ilo: 10.105.255.45	2012-11-28 11:29:33.667677	2012-12-07 14:38:32.960349	Zone Server	Solaris 10	1	\N	Six-Core AMD Opteron, 2600 MHz 	f	\N	\N	f	\N
17	mpzz101	\N	16	2		13	4	\N	\N	\N	Live	\N	22		2012-11-26 16:02:25.03914	2012-12-07 14:38:32.965122	Zone Server	Solaris 10	1	\N		f	\N	\N	f	\N
26	ipzz611	\N	20	1	CZJ1140X05	14	12	2	\N	32	Dev	\N	23	10.105.33.13	2012-11-27 14:39:45.156399	2012-12-07 14:38:33.03105	Zone server	Solaris 10	1	\N	Six-Core Intel Xeon, 3067 MHz 	f	\N	\N	f	\N
30	ipzz614	\N	20	1	CZJ1140WZY	14	12	2	\N	32	Dev	\N	23	ilo: 10.105.33.19	2012-11-27 14:51:11.433025	2012-12-07 14:38:33.052614	Zone Server	Solaris 10	1	\N	Six-Core Intel Xeon, 3067 MHz 	f	\N	\N	f	\N
35	baap102	\N	\N	2	1002QBU011	23	7	4	\N	128	Live	\N	2	10.129.255.51	2012-11-28 10:45:20.068307	2012-12-07 14:38:33.057924	Application - Online	Solaris 10	1	\N	6-Core AMD Opteron 8439 2.8GHz  CPU 	f	\N	\N	f	\N
31	ipap618	\N	26	1		14	4	4	\N	4	Dev	\N	23		2012-11-27 15:28:09.604263	2012-12-07 14:38:33.063207	IPS Back Office Instance 1 	Solaris 10	1	\N	Threads	f	\N	\N	f	\N
38	ipap616	\N	27	1		14	4	\N	\N	\N	Dev	\N	23		2012-11-28 12:38:21.245	2012-12-07 14:38:33.11926	unknown	Solaris 10	1	\N		f	\N	\N	f	\N
1	dvzz601	f	\N	1	0743AN1415	1	1	8	1	196	Dev	\N	20	dvzz601-con	2012-10-19 12:00:37.970734	2012-12-07 14:38:33.251031	Zone Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 8220 (16Cores) 	f	\N	\N	f	\N
2	spap601	t	1	1		1	25	\N	\N	\N	Dev	\N	21	\N	2012-10-22 13:16:46.867785	2012-12-07 14:38:33.280783	Application Server	Solaris 10	1	1	\N	f	\N	\N	f	\N
15	spap602	\N	1	1		1	25	\N	\N	\N	Dev	\N	21		2012-11-26 14:25:20.704768	2012-12-07 14:38:33.303151	Application server	Solaris 10	1	\N		f	\N	\N	f	\N
37	dvzz604	\N	3	1	CZJ04507J6	2	13	4	\N	128	Dev	\N	20	ilo: 10.105.255.49	2012-11-28 11:31:43.034096	2012-12-07 14:38:33.315144	Zone Server	Solaris 10	1	\N	Six-Core AMD Opteron, 2600 MHz 	f	\N	\N	f	\N
16	mpld101	\N	\N	2	1225BDY104	13	8	1	\N	64	Live	\N	22	10.129.255.11	2012-11-26 16:00:28.883836	2012-12-07 14:38:33.335192	LDOM provider	Solaris 10	1	\N	Sparc T4 - 8 Core	f	\N	\N	f	\N
3	ifbc601	\N	\N	1	GB894051R9	2	2	\N	\N	\N	Dev	\N	20	https://10.105.255.20/	2012-11-23 15:25:03.107218	2012-12-07 14:38:32.881875	\N	None	1	\N		f	\N	\N	f	\N
21	cm201	\N	\N	1	223Q0029	15	11	4	\N	8	DR	\N	24	termserv_dun Raritan user: platform	2012-11-27 12:22:32.650109	2012-12-07 14:38:33.342201	Clearcase contingency	Solaris 8	1	\N	1200MHz 	f	\N	\N	f	\N
22	cm301	\N	\N	1	0402AN008B	16	11	8	\N	24	DR	\N	24	termserv_dun Raritan user: platform	2012-11-27 12:25:29.793586	2012-12-07 14:38:33.366767	Configuration Management	Solaris 8	1	\N	1200MHz 	f	\N	\N	f	\N
23	ifex602	\N	3	1	CZC9481HWN	2	3	8	\N	196	Dev	\N	20	https://10.105.255.39/	2012-11-27 12:33:49.863701	2012-12-07 14:38:33.372123	Dunstable VMWare Cluster	ESX 4.1	1	\N	2.933 Ghz	f	\N	\N	f	\N
27	ipzz612	\N	20	1	CZJ1140G36	14	12	2	\N	32	Dev	\N	23	ilo: 10.105.33.14	2012-11-27 14:44:24.832339	2012-12-07 14:38:33.397483	Zone Server	Solaris 10	1	\N	Six-Core Intel Xeon, 3067 MHz 	f	\N	\N	f	\N
28	ipzz613	\N	20	1	CZJ1100TD7	14	12	2	\N	36	Dev	\N	23	ILO: 10.105.33.15	2012-11-27 14:47:07.907877	2012-12-07 14:38:33.403049	Zone Server	Solaris 10	1	\N	Six-Core Intel Xeon, 3067 MHz 	f	\N	\N	f	\N
29	ipdb611	\N	20	1	CZJ1140X02	14	12	2	\N	32	Dev	\N	23	ilo: 10.105.33.17	2012-11-27 14:49:41.617221	2012-12-07 14:38:33.408655	DB	Solaris 10	1	\N	Six-Core Intel Xeon, 3067 MHz 	f	\N	\N	f	\N
25	ap205	\N	\N	1	0546NNN19M	22	6	1	\N	32	DR	\N	17	10.100.2.68, telnet from 10.100.2.x	2012-11-27 14:29:52.163549	2012-12-07 14:38:33.427725	STS/ETS App server	Solaris 10	1	1	UltraSPARC-T1 (8 Cores) 1.2GHz 	f	\N	\N	f	\N
44	ipap612	\N	30	1		14	4	8	\N	8	Dev	\N	23		2012-11-28 12:47:36.485887	2012-12-07 14:38:32.899018	IPS switch 3 - Site 2  	Solaris 10	1	\N	Threads	f	\N	\N	f	\N
11	badb503	\N	10	1		9	4	\N	\N	\N	Dev	\N	2		2012-11-26 11:40:58.710675	2012-12-07 14:38:32.90923	DB	Solaris 10	1	\N		f	\N	\N	f	\N
18	mpap101	\N	17	2		13	4	\N	\N	\N	Live	\N	22		2012-11-26 16:03:55.852936	2012-12-07 14:38:32.970015	Application server	Solaris 10	1	\N		f	\N	\N	f	\N
19	mpdb111	\N	17	2		13	4	\N	\N	\N	Live	\N	22		2012-11-26 16:04:39.447429	2012-12-07 14:38:32.991671	DB	Solaris 10	1	\N		f	\N	\N	f	\N
20	ipbc611	\N	\N	1	CZ211507NR	14	9	0	\N	\N	Dev	\N	23	https://10.105.33.11/	2012-11-26 17:15:46.444859	2012-12-07 14:38:32.999312	Blade Enclosure	None	1	\N	None	f	\N	\N	f	\N
32	ipap620	\N	26	1		14	4	\N	\N	\N	Dev	\N	23		2012-11-27 15:30:27.408462	2012-12-07 14:38:33.084563	IPS Switch (all sites) 	Solaris 10	1	\N		f	\N	\N	f	\N
33	ipap621	\N	26	1		14	4	\N	\N	\N	Dev	\N	23		2012-11-27 15:31:55.10776	2012-12-07 14:38:33.08934	IPS Back office 	Solaris 10	1	\N		f	\N	\N	f	\N
34	ipap622	\N	26	1		14	4	4	\N	4	Dev	\N	23		2012-11-27 15:33:21.720212	2012-12-07 14:38:33.095113	IPS MQ manager  	Solaris 10	1	\N	Threads	f	\N	\N	f	\N
8	baap103	\N	\N	2	1002QBU015	8	7	4	\N	128	Live	\N	2	10.129.255.52 	2012-11-26 11:25:45.575391	2012-12-07 14:38:33.114353	Application - Batch	Solaris 10	1	1	6-Core AMD Opteron 8439 2.8GHz  CPU 	f	\N	\N	f	\N
39	ipap623	\N	27	1		14	4	4	\N	\N	Dev	\N	23		2012-11-28 12:39:25.387768	2012-12-07 14:38:33.124069	Bank MQ manager 	Solaris 10	1	\N	Threads	f	\N	\N	f	\N
40	ipap613	\N	27	1		14	4	4	\N	4	Dev	\N	23		2012-11-28 12:40:29.943813	2012-12-07 14:38:33.14713	IPS Back Office Instance 2 	Solaris 10	1	\N	Threads	f	\N	\N	f	\N
41	ipap617	\N	27	1		14	4	10	\N	8	Dev	\N	23		2012-11-28 12:41:28.57323	2012-12-07 14:38:33.152326	IPS Load generator 	Solaris 10	1	\N	Threads	f	\N	\N	f	\N
42	ipap611	\N	28	1		14	4	8	\N	8	Dev	\N	23		2012-11-28 12:44:37.273497	2012-12-07 14:38:33.158355	IPS switch 1 - Site 1  	Solaris 10	1	\N	Threads	f	\N	\N	f	\N
43	ipap614	\N	28	1		14	4	8	\N	8	Dev	\N	23		2012-11-28 12:45:58.482995	2012-12-07 14:38:33.17856	IPS switch 2 - Site 1  	Solaris 10	1	\N	Threads	f	\N	\N	f	\N
45	ipap615	\N	30	1		14	4	8	\N	8	Dev	\N	23		2012-11-28 12:48:20.654322	2012-12-07 14:38:33.184274	IPS switch 4 - Site 2  	Solaris 10	1	\N	Threads	f	\N	\N	f	\N
46	fdb503	\N	10	1		9	4	\N	\N	\N	Dev	\N	11		2012-11-29 11:57:36.905831	2012-12-07 14:38:33.18971	DB	Solaris 10	1	\N		f	\N	\N	f	\N
47	fdb512	\N	10	1		9	4	\N	\N	\N	Dev	\N	11		2012-11-29 12:00:03.253279	2012-12-07 14:38:33.210899	DB	Solaris 10	1	\N		f	\N	\N	f	\N
48	fdb513	\N	10	1		9	4	\N	\N	\N	Dev	\N	11		2012-11-29 12:02:26.585954	2012-12-07 14:38:33.216713	DB	Solaris 10	1	\N		f	\N	\N	f	\N
49	ecdb614	\N	10	1		9	4	\N	\N	\N	Dev	\N	1		2012-11-29 12:03:08.1432	2012-12-07 14:38:33.222667	DB	Solaris 10	1	\N		f	\N	\N	f	\N
50	ecdb801	\N	10	1		9	4	\N	\N	\N	Dev	\N	1		2012-11-29 12:04:34.226078	2012-12-07 14:38:33.241501	DB	Solaris 10	1	\N		f	\N	\N	f	\N
9	badb101	\N	\N	2	BCF094302A	8	21	6	\N	96	Live	\N	2	10.129.255.54	2012-11-26 11:27:31.400891	2012-12-07 14:38:33.246543	DB	Solaris 10	1	1	Quad-Core 2.53 GHz SPARC64 VII    	f	\N	\N	f	\N
61	suteddb201	\N	\N	1	0720AN1041	33	14	4	\N	32	UAT	\N	1		2012-11-29 14:43:44.864541	2012-12-07 14:38:33.555113	DB	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
69	baap303	\N	\N	1	1002QBU01A	36	7	4	\N	128	TT	\N	2	10.104.255.68 	2012-11-29 15:13:14.454719	2012-12-07 14:38:33.564444	Application	Solaris 10	1	\N	6-Core AMD Opteron 8439 2.8GHz  CPU  	f	\N	\N	f	\N
70	baap304	\N	\N	1	1002QBU018	36	7	4	\N	128	TT	\N	2	10.104.255.69	2012-11-29 15:15:36.834988	2012-12-07 14:38:33.590847	Application	Solaris 10	1	\N	6-Core AMD Opteron 8439 2.8GHz  CPU 	f	\N	\N	f	\N
13	dedb502	\N	10	1		9	25	\N	\N	\N	UAT	\N	13		2012-11-26 12:03:01.239215	2012-12-21 11:30:40.551456	DB	Solaris 10	1	1		f	\N	\N	f	\N
5	dvzz602	\N	\N	1	BCF074607Q	63	21	4	\N	192	Dev	\N	20	dvzz602-con	2012-11-23 15:57:21.061195	2012-12-21 18:15:40.008287	Zone server	Solaris 10	1	1	QuadCore-2.66GHz  +  QuadCore-2.4GHz	f	\N	\N	f	\N
6	ap105	\N	\N	2	0645NNN0AE	7	6	1	\N	32	Live	\N	17	10.129.2.68	2012-11-26 11:19:34.483852	2012-12-21 15:03:58.000741	STS/ETS App server	Solaris 10	1	1	UltraSPARC-T1 (8 Cores) 1.2GHz	f	\N	\N	f	\N
80	badb403	\N	74	1		37	4	\N	\N	\N	UAT	\N	2		2012-11-29 16:01:32.774345	2012-12-07 14:38:33.594114	DB	Solaris 10	1	\N		f	\N	\N	f	\N
98	bcap603	t	1	1		1	25	\N	\N	\N	Dev	\N	16		2012-11-30 11:34:50.961208	2012-12-07 14:38:33.736518	Application Server	Solaris 10	1	1		f	\N	\N	f	\N
96	sutfap201	\N	\N	1	0617NNN073	22	6	1	\N	32	SUT	\N	11	10.100.55.60	2012-11-30 10:51:44.904291	2012-12-07 14:38:33.741323	DD/Core/Settlement/Distra App server	Solaris 10	1	\N	UltraSPARC-T1 (8 Cores) 1.2GHz 	f	\N	\N	f	\N
76	badb301	\N	\N	1	BCF0821046	39	21	8	\N	96	TT	\N	2	10.104.255.16 via uxif301-joz	2012-11-29 15:30:13.404974	2012-12-07 14:38:33.751166	DB	Solaris 10	1	1	2 x QuadCore-2.66GHz + 2 x QuadCore-2.53GHz + 4 x QuadCore-2.15GHz (32 Cores) 	f	\N	\N	f	\N
74	crzz401	\N	\N	1	BCF0822027	37	21	8	\N	128	Dev	\N	20	10.105.255.58	2012-11-29 15:27:06.910214	2012-12-07 14:38:33.772974	Zone Server	Solaris 10	1	1	DualCore 2.15GHz  UltraSPARC VI 	f	\N	\N	f	\N
77	badb302	\N	\N	1	BCF082103L	38	21	8	\N	96	TT	\N	2	10.104.255.17	2012-11-29 15:31:36.741656	2012-12-07 14:38:33.779097	DB	Solaris 10	1	1	2 x QuadCore-2.66GHz + 2 x QuadCore-2.53GHz + 4 x QuadCore-2.15GHz (32 Cores) 	f	\N	\N	f	\N
75	utzz502	\N	\N	1	BCF0822009	38	21	6	\N	104	Dev	\N	20	10.100.255.57	2012-11-29 15:28:43.036358	2012-12-07 14:38:33.786881	Zone Server	Solaris 10	1	1	QuadCore 2.66GHz  UltraSPARC VII 	f	\N	\N	f	\N
51	fdb502	\N	10	1		9	4	\N	\N	\N	Dev	\N	11		2012-11-29 12:05:18.357121	2012-12-07 14:38:33.43283	DB	Solaris 10	1	\N		f	\N	\N	f	\N
92	entbc201	\N	\N	1		42	2	\N	\N	\N	DR	\N	20	https://10.100.255.47/ tt- 'padmin'	2012-11-29 17:45:34.917202	2012-12-07 14:38:33.791844	Blade Enclosure		1	1		f	\N	\N	f	\N
97	bcap601	t	1	1		1	25	\N	\N	\N	Dev	\N	16		2012-11-30 11:33:32.211846	2012-12-07 14:38:33.796531	Application Server	Solaris 10	1	1		f	\N	\N	f	\N
94	bcap602	t	1	1		1	25	\N	\N	\N	Dev	\N	16		2012-11-29 18:01:12.139279	2012-12-07 14:38:33.800868	Application Server	Solaris 10	1	1		f	\N	\N	f	\N
7	baap101	\N	\N	2	1002QBU010	8	7	4	\N	128	Live	\N	2	10.129.255.50 	2012-11-26 11:23:15.417124	2012-12-07 14:38:33.80592	Application - Online	Solaris 10	1	1	\N	f	\N	\N	f	\N
66	baap204	\N	\N	1	1002QBU012	35	7	4	\N	128	DR	\N	2	10.100.255.36	2012-11-29 15:05:55.53354	2012-12-07 14:38:33.810659	Application - Batch	Solaris 10	1	\N	6-Core AMD Opteron 8439 2.8GHz  CPU 	f	\N	\N	f	\N
67	baap301	\N	\N	1	1002QBU016	36	7	4	\N	128	TT	\N	2	10.104.255.66	2012-11-29 15:09:11.872097	2012-12-07 14:38:33.814954	Application - Online	Solaris 10	1	1	6-Core AMD Opteron 8439 2.8GHz  CPU  	f	\N	\N	f	\N
79	dedb302	\N	\N	1	0732AN1240	9	14	4	\N	32	TT	\N	13		2012-11-29 15:47:07.973177	2012-12-07 14:38:33.83528	DB	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores) 	f	\N	\N	f	\N
62	baap104	\N	\N	2	1002QBU013	23	7	4	\N	128	Live	\N	2	10.129.255.53	2012-11-29 14:52:29.866744	2012-12-07 14:38:33.84173	Application - Batch 	Solaris 10	1	1	6-Core AMD Opteron 8439 2.8GHz  CPU	f	\N	\N	f	\N
52	fdb501	\N	10	1		9	4	\N	\N	\N	Dev	\N	11		2012-11-29 12:05:57.399261	2012-12-07 14:38:33.438165	DB	Solaris 10	1	\N		f	\N	\N	f	\N
53	badb513	\N	10	1		9	4	\N	\N	\N	Dev	\N	2		2012-11-29 12:06:34.881284	2012-12-07 14:38:33.459326	DB	Solaris 10	1	\N		f	\N	\N	f	\N
54	badb511	\N	10	1		9	4	\N	\N	\N	Dev	\N	2		2012-11-29 12:07:38.736258	2012-12-07 14:38:33.464685	DB	Solaris 10	1	\N		f	\N	\N	f	\N
55	badb502	\N	10	1		9	4	\N	\N	\N	Dev	\N	2		2012-11-29 12:08:52.751507	2012-12-07 14:38:33.469845	DB	Solaris 10	1	\N		f	\N	\N	f	\N
56	baor501	\N	10	1		9	4	\N	\N	\N	Dev	\N	2		2012-11-29 12:09:30.590184	2012-12-07 14:38:33.490258	Oracle Reports Server	Solaris 10	1	\N		f	\N	\N	f	\N
57	fdb511	\N	10	1		9	4	\N	\N	\N	Dev	\N	11		2012-11-29 12:09:59.454699	2012-12-07 14:38:33.496138	DB	Solaris 10	1	\N		f	\N	\N	f	\N
59	mpdb501	\N	10	1		9	4	\N	\N	\N	Dev	\N	22		2012-11-29 12:16:16.509976	2012-12-07 14:38:33.521565	DB	Solaris 10	1	\N		f	\N	\N	f	\N
60	mpdb511	\N	10	1		9	4	\N	\N	\N	Dev	\N	22		2012-11-29 12:16:47.530994	2012-12-07 14:38:33.527304	DB	Solaris 10	1	\N		f	\N	\N	f	\N
89	bcpx203	\N	\N	1	0821QAU075	37	15	2	\N	4	DR	\N	16	192.168.231.126	2012-11-29 16:24:24.834214	2012-12-07 14:38:33.532188	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
65	baap203	\N	\N	1	1002QBU00E	34	7	4	\N	128	DR	\N	2	10.100.255.35	2012-11-29 15:03:43.994048	2012-12-07 14:38:33.551872	Application - Batch	Solaris 10	1	\N	6-Core AMD Opteron 8439 2.8GHz  CPU 	f	\N	\N	f	\N
63	baap201	\N	\N	1	1002QBU017	34	7	4	\N	128	DR	\N	2	10.100.255.33 	2012-11-29 14:57:34.574888	2012-12-07 14:38:33.558152	Application - Online	Solaris 10	1	\N	6-Core AMD Opteron 8439 2.8GHz  CPU  	f	\N	\N	f	\N
64	baap202	\N	\N	1	1002QBU00F	35	7	4	\N	128	DR	\N	2	10.100.255.34	2012-11-29 14:59:29.16812	2012-12-07 14:38:33.561331	Application - Online	Solaris 10	1	1	6-Core AMD Opteron 8439 2.8GHz  CPU 	f	\N	\N	f	\N
78	deap302	\N	\N	1	0822QAU03F	9	7	2	\N	16	TT	\N	13		2012-11-29 15:45:27.390008	2012-12-07 14:38:33.584302	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
81	fdb401	\N	74	1		37	4	\N	\N	\N	UAT	\N	11		2012-11-29 16:02:30.536574	2012-12-07 14:38:33.614327	DB	Solaris 10	1	\N		f	\N	\N	f	\N
82	fdb403	\N	74	1		37	4	\N	\N	\N	UAT	\N	11		2012-11-29 16:03:15.900161	2012-12-07 14:38:33.618087	DB	Solaris 10	1	\N		f	\N	\N	f	\N
83	badb401	\N	74	1		37	4	\N	\N	\N	UAT	\N	2		2012-11-29 16:04:26.677871	2012-12-07 14:38:33.62117	DB	Solaris 10	1	\N		f	\N	\N	f	\N
84	fdb402	\N	74	1		37	4	\N	\N	\N	UAT	\N	11		2012-11-29 16:05:20.684841	2012-12-07 14:38:33.624527	DB	Solaris 10	1	\N		f	\N	\N	f	\N
85	bcap201	\N	\N	1	0822QAU022	37	7	2	\N	64	DR	\N	16	10.100.255.40	2012-11-29 16:09:54.934349	2012-12-07 14:38:33.646609	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
86	bcap203	\N	\N	1	0821QAU089	37	7	2	\N	64	DR	\N	16	10.100.255.42	2012-11-29 16:15:04.69522	2012-12-07 14:38:33.651604	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
87	bcap205	\N	\N	1	0821QAU025	37	7	2	\N	64	DR	\N	16	10.100.255.44	2012-11-29 16:18:53.978951	2012-12-07 14:38:33.656645	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
88	bcpx201	\N	\N	1	0822QAU020	37	15	2	\N	4	DR	\N	16	192.168.231.120	2012-11-29 16:22:47.551063	2012-12-07 14:38:33.678049	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
90	entbc101	\N	\N	2		40	2	\N	\N	\N	Live	\N	20		2012-11-29 17:42:35.15282	2012-12-07 14:38:33.681662	Blade Enclosure		1	\N		f	\N	\N	f	\N
91	entbc102	\N	\N	2		41	2	\N	\N	\N	Live	\N	20		2012-11-29 17:44:02.677335	2012-12-07 14:38:33.685703	Blade Enclosure		1	\N		f	\N	\N	f	\N
93	entbc202	\N	\N	1		43	2	\N	\N	\N	DR	\N	20		2012-11-29 17:46:11.431608	2012-12-07 14:38:33.690057	Blade Enclosure		1	\N		f	\N	\N	f	\N
71	badb102	\N	\N	2	BCF094302C	23	21	6	\N	96	Live	\N	2	10.129.255.55	2012-11-29 15:17:11.385827	2012-12-07 14:38:33.709272	DB	Solaris 10	1	1	Quad-Core 2.53 GHz SPARC64 VII    	f	\N	\N	f	\N
73	badb202	\N	\N	1	BCF094502X	35	21	6	\N	96	DR	\N	2	10.100.255.38	2012-11-29 15:24:55.418654	2012-12-07 14:38:33.746926	DB	Solaris 10	1	1	Quad-Core 2.53 GHz SPARC64 VII    	f	\N	\N	f	\N
123	uxif205	\N	\N	1	0817ALB278	1	18	1	\N	2	DR	\N	20		2012-11-30 13:20:22.871949	2012-12-07 14:38:33.879574	Jumpstart	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2218 - 2.6GHz 	f	\N	\N	f	\N
128	ttfdb204	\N	\N	1	BCF0751062	44	21	8	\N	32	TT	\N	11	10.104.2.162	2012-11-30 15:01:38.552596	2012-12-07 14:38:33.907772	DB - EDW	Solaris 10	1	1	DualCore 2.15GHz  UltraSPARC VI	f	\N	\N	f	\N
126	fap304	\N	\N	1	0821QAU07C	44	7	2	\N	16	TT	\N	11	10.104.255.24	2012-11-30 14:52:59.431164	2012-12-07 14:38:33.912761	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
132	aszz610	\N	\N	3	1110FMM1EV	46	22	2	\N	48	Dev	\N	25	Not stated.	2012-12-03 12:46:54.170856	2012-12-07 14:38:33.918031	AMS WP Web Server / TA Proxy Server - Dev & Test	Solaris 10	1	\N	6 core Intel Xeon X5670@2.93GHx	f	\N	\N	f	\N
58	csmtest	\N	10	1		9	25	\N	\N	\N	CT	\N	1		2012-11-29 12:15:24.660845	2012-12-21 14:16:55.594515	Test DB	Solaris 10	1	1		f	\N	\N	f	\N
72	badb201	\N	\N	1	BCF094502W	34	21	6	\N	96	DR	\N	2	10.100.255.37	2012-11-29 15:23:42.915536	2012-12-07 14:38:33.931632	DB	Solaris 10	1	1	Quad-Core 2.53 GHz SPARC64 VII    	f	\N	\N	f	\N
129	bcap302	\N	\N	1	0822QAU030	38	7	2	\N	64	TT	\N	16	10.104.255.11	2012-11-30 17:56:29.423803	2012-12-07 14:38:33.942074	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
139	bcap106	\N	\N	2	0822QAU013	48	7	2	\N	64	Live	\N	16	10.129.255.45	2012-12-03 13:04:23.27708	2012-12-07 14:38:33.964227	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
135	bcap102	\N	\N	2	0822QAU038	48	7	2	\N	64	Live	\N	16	10.129.255.41	2012-12-03 12:57:44.672153	2012-12-07 14:38:33.974543	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
137	bcap103	\N	\N	2	0822QAU01E	47	7	2	\N	64	Live	\N	16	10.129.255.42	2012-12-03 13:00:30.296812	2012-12-07 14:38:33.980595	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
136	bcap104	\N	\N	2	0821QAU071	48	7	2	\N	64	Live	\N	16	10.129.255.43	2012-12-03 12:59:07.986151	2012-12-07 14:38:33.985559	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
140	bcap202	\N	\N	1	0821QAU08A	49	7	2	\N	64	DR	\N	16	10.100.255.41	2012-12-03 13:09:14.735232	2012-12-07 14:38:33.990828	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
116	bcpx603	t	1	1		1	25	\N	\N	\N	Dev	\N	16		2012-11-30 13:01:55.44278	2012-12-07 14:38:34.017066	Proxy Server	Solaris 10	1	1		f	\N	\N	f	\N
115	sm601	\N	1	1		1	25	\N	\N	\N	Dev	\N	20		2012-11-30 12:59:57.363582	2012-12-07 14:38:34.022659	No idea	Solaris 10	1	1		f	\N	\N	f	\N
102	decl601	t	1	1		1	25	\N	\N	\N	Dev	\N	13		2012-11-30 11:39:01.081702	2012-12-07 14:38:34.027767	ETS/STS Client	Solaris 10	1	1		f	\N	\N	f	\N
104	dv307	\N	1	1		1	25	\N	\N	\N	Dev	\N	20		2012-11-30 11:55:28.046053	2012-12-07 14:38:34.033192	ADG Dev database	Solaris 10	1	\N		f	\N	\N	f	\N
105	dv308	\N	1	1		1	25	\N	\N	\N	Dev	\N	20		2012-11-30 12:03:14.785177	2012-12-07 14:38:34.03851	ADG Weblogic	Solaris 10	1	\N		f	\N	\N	f	\N
106	dv310	\N	1	1		1	25	\N	\N	\N	Dev	\N	20		2012-11-30 12:04:33.68906	2012-12-07 14:38:34.04368	ADG Doesnt look like much is going on there	Solaris 10	1	\N		f	\N	\N	f	\N
107	dwap601	\N	1	1		1	25	\N	\N	\N	Dev	\N	21		2012-11-30 12:06:45.974408	2012-12-07 14:38:34.048971	Application	Solaris 10	1	\N		f	\N	\N	f	\N
95	spap604	t	1	1		1	25	\N	\N	\N	Dev	\N	21		2012-11-29 18:03:30.604348	2012-12-07 14:38:34.054138	Application	Solaris 10	1	1		f	\N	\N	f	\N
109	ecap601	\N	1	1		1	25	\N	\N	\N	Dev	\N	1		2012-11-30 12:54:27.496611	2012-12-07 14:38:34.059102	Application	Solaris 10	1	\N		f	\N	\N	f	\N
110	ecap602	\N	1	1		1	25	\N	\N	\N	Dev	\N	1		2012-11-30 12:55:13.30812	2012-12-07 14:38:34.064263	Application	Solaris 10	1	\N		f	\N	\N	f	\N
111	ecap604	\N	1	1		1	25	\N	\N	\N	Dev	\N	1		2012-11-30 12:55:23.634641	2012-12-07 14:38:34.070585	Application	Solaris 10	1	\N		f	\N	\N	f	\N
112	ecap605	\N	1	1		1	25	\N	\N	\N	Dev	\N	1		2012-11-30 12:55:31.336953	2012-12-07 14:38:34.076112	Application	Solaris 10	1	\N		f	\N	\N	f	\N
113	expx602	\N	1	1		1	25	\N	\N	\N	Dev	\N	1		2012-11-30 12:56:08.054058	2012-12-07 14:38:34.082536	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
114	expx604	\N	1	1		1	25	\N	\N	\N	Dev	\N	1		2012-11-30 12:56:17.492841	2012-12-07 14:38:34.088256	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
118	spap605	t	1	1		1	25	\N	\N	\N	Dev	\N	21	\N	2012-11-30 13:02:50.597629	2012-12-07 14:38:34.093632	Application Server	Solaris 10	1	1	\N	f	\N	\N	f	\N
119	spem601	t	1	1		1	25	\N	\N	\N	Dev	\N	21	\N	2012-11-30 13:03:29.537232	2012-12-07 14:38:34.099064	EM? Environment Monitoring?	Solaris 10	1	1	\N	f	\N	\N	f	\N
122	uxif204	\N	\N	1	0819ALB659	1	18	1	\N	2	DR	\N	20		2012-11-30 13:17:22.045334	2012-12-07 14:38:34.104163	Jumpstart	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2218 - 2.6GHz 	f	\N	\N	f	\N
103	deap601	\N	1	1		1	25	\N	\N	\N	Dev	\N	13		2012-11-30 11:45:40.056841	2012-12-07 14:38:33.847305	Application	Solaris 10	1	1		f	\N	\N	f	\N
108	dwpx601	\N	1	1		1	25	\N	\N	\N	Dev	\N	21		2012-11-30 12:49:29.515303	2012-12-07 14:38:33.872357	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
125	uxif305	\N	\N	1	0820ALB6F2	1	18	1	\N	2	TT	\N	20	10.104.70.13	2012-11-30 13:25:56.248092	2012-12-07 14:38:33.897643	Jumpstart	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2218 - 2.6GHz 	f	\N	\N	f	\N
120	cm302	\N	\N	1	0748AL8563	1	17	2	\N	8	Dev	\N	24	10.105.2.239	2012-11-30 13:06:31.959665	2012-12-07 14:38:33.902784	Configuration Management	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz) 	f	\N	\N	f	\N
10	utzz501	\N	\N	1	BCF0943003	9	21	8	\N	128	UAT	\N	20	10.105.255.10	2012-11-26 11:32:03.639329	2012-12-07 14:38:33.925628	Zone Server	Solaris 10	1	1	6 x Quad-Core 2.53 GHz SPARC64 VII   + 2 x DualCore 2.15GHz (28 Cores)	f	\N	\N	f	\N
127	fdb306	\N	\N	1	BCF082105A	44	21	4	\N	32	TT	\N	11	10.104.255.27	2012-11-30 14:57:43.713484	2012-12-07 14:38:33.936843	DB FPS0-TT & SEC	Solaris 10	1	1	2xDualCore 2.15GHz + 2xQuadCore 2.4GHz (12Cores)	f	\N	\N	f	\N
130	ap206	\N	\N	1	0548NNN0WK	22	6	1	\N	32	DR	\N	17	10.100.2.115 from 10.100.2.0/24	2012-12-03 10:11:42.258602	2012-12-07 14:38:33.948263	STS/ETS App server	Solaris 10	1	1	UltraSPARC-T1 (8 Cores) 1.2GHz 	f	\N	\N	f	\N
133	aszz620	\N	\N	3	1110FMM1EW	46	22	1	\N	24	Dev	\N	25	Not stated.	2012-12-03 12:50:24.082063	2012-12-07 14:38:33.954056	AMS WP Web Server / TA Proxy Server - Dev & Test	Solaris 10	1	\N	6 core Intel Xeon X5670@2.93GHx	f	\N	\N	f	\N
138	bcap105	\N	\N	2	0822QAU026	47	7	2	\N	64	Live	\N	16	10.129.255.44	2012-12-03 13:02:37.072603	2012-12-07 14:38:33.95924	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
134	bcap101	\N	\N	2	0821QAU06C	47	7	2	\N	64	Live	\N	16	10.129.255.40	2012-12-03 12:53:35.910194	2012-12-07 14:38:33.969541	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
141	bcap204	\N	\N	1	0821QAU077	49	7	2	\N	64	DR	\N	16	10.100.255.43	2012-12-03 13:10:02.335522	2012-12-07 14:38:33.996031	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
142	bcap206	\N	\N	1	0822QAU01D	49	7	2	\N	64	DR	\N	16	10.100.255.45	2012-12-03 13:10:35.41735	2012-12-07 14:38:34.001641	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222 	f	\N	\N	f	\N
100	bcpx601	t	1	1		1	25	\N	\N	\N	Dev	\N	16		2012-11-30 11:38:42.97617	2012-12-07 14:38:34.00732	Proxy Server	Solaris 10	1	1		f	\N	\N	f	\N
124	uxif304	\N	\N	1	0819ALB65A	1	18	1	\N	2	TT	\N	20	10.104.255.20	2012-11-30 13:22:17.045458	2012-12-07 14:38:34.115707	Jumpstart	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2218 - 2.6GHz 	f	\N	\N	f	\N
143	bcap301	\N	\N	1	0822QAU035	39	7	2	\N	64	TT	\N	16	10.104.255.10	2012-12-03 13:12:39.279948	2012-12-07 14:38:34.12076	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
146	bcap304	\N	\N	1	0821QAU050	38	7	2	\N	64	TT	\N	16	10.104.255.13	2012-12-03 13:17:08.436036	2012-12-07 14:38:34.125805	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
144	bcap303	\N	\N	1	0821QAU05A	39	7	2	\N	64	TT	\N	16	10.104.255.12	2012-12-03 13:13:32.659693	2012-12-07 14:38:34.130981	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
145	bcap305	\N	\N	1	0821QAU08D	39	7	2	\N	64	TT	\N	16	10.104.255.14	2012-12-03 13:16:11.657142	2012-12-07 14:38:34.136297	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
147	bcap306	\N	\N	1	0822QAU00F	38	7	2	\N	64	TT	\N	16	10.104.255.15	2012-12-03 13:17:42.723516	2012-12-07 14:38:34.141775	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
148	bcdb101	\N	\N	2	BCF083700N	47	21	4	\N	96	Live	\N	16	10.129.255.16	2012-12-03 13:20:10.809428	2012-12-07 14:38:34.147482	DB	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI	f	\N	\N	f	\N
192	baap603	\N	150	1		2	24	4	\N	32	Dev	\N	2		2012-12-03 17:17:00.03364	2012-12-07 14:38:34.444166	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
181	baap401	\N	150	1		2	24	2	\N	48	CR	\N	2		2012-12-03 17:06:48.507715	2012-12-07 14:38:34.506676	Application	Solaris 10	1	1	vCPU	f	\N	\N	f	\N
149	bcdb102	\N	\N	2	BCF083707Y	48	21	4	\N	96	Live	\N	16	10.129.255.17	2012-12-03 13:20:50.739622	2012-12-07 14:38:34.153307	DB	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI	f	\N	\N	f	\N
150	DUNSTABLE-1	\N	3	1		2	23	96	\N	2050	Dev	\N	20		2012-12-03 16:55:19.598931	2012-12-07 14:38:34.161207	vsphere cluster	ESX 4.1	1	\N	2.933 Ghz	f	\N	\N	f	\N
151	ipap651	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:57:28.060795	2012-12-07 14:38:34.167274	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
152	ipap652	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:58:02.600089	2012-12-07 14:38:34.173018	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
153	ipap653	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:58:19.730981	2012-12-07 14:38:34.179286	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
154	ipap654	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:58:52.738029	2012-12-07 14:38:34.184979	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
155	ipap655	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:59:02.213131	2012-12-07 14:38:34.190701	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
156	ipap656	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:59:11.701281	2012-12-07 14:38:34.22226	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
157	ipap657	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:59:20.77216	2012-12-07 14:38:34.228696	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
158	ipap658	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:59:32.21306	2012-12-07 14:38:34.234753	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
159	ipap659	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:59:40.895353	2012-12-07 14:38:34.241605	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
160	ipap660	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:59:48.099256	2012-12-07 14:38:34.247749	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
161	ipap661	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 16:59:58.283896	2012-12-07 14:38:34.253312	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
162	ipap662	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:00:06.827324	2012-12-07 14:38:34.259872	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
163	ipap663	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:00:15.619639	2012-12-07 14:38:34.266147	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
164	ipap664	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:00:26.841214	2012-12-07 14:38:34.272548	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
166	ipap666	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:00:40.976631	2012-12-07 14:38:34.286998	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
167	ipap667	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:00:47.922573	2012-12-07 14:38:34.294629	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
168	ipap668	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:00:58.315292	2012-12-07 14:38:34.300221	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
169	ipap669	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:01:18.820312	2012-12-07 14:38:34.30607	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
170	ipap670	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:01:25.907164	2012-12-07 14:38:34.311713	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
171	ipap671	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:01:32.883323	2012-12-07 14:38:34.317928	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
172	ipap672	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:01:39.491769	2012-12-07 14:38:34.324024	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
173	ipap673	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:01:46.336339	2012-12-07 14:38:34.33567	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
174	ipap674	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:01:52.87939	2012-12-07 14:38:34.341558	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
175	ipap675	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:01:59.125747	2012-12-07 14:38:34.349258	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
176	ipap676	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:02:05.17309	2012-12-07 14:38:34.354658	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
177	ipap677	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:02:12.318986	2012-12-07 14:38:34.360589	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
178	ipap678	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:02:18.685133	2012-12-07 14:38:34.366173	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
179	ipap679	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:02:25.188153	2012-12-07 14:38:34.371895	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
180	ipap680	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:02:33.940095	2012-12-07 14:38:34.378277	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
182	baap402	\N	150	1		2	24	2	\N	48	CR	\N	2		2012-12-03 17:07:01.016597	2012-12-07 14:38:34.384169	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
183	baap501	\N	150	1		2	24	4	\N	64	Dev	\N	2		2012-12-03 17:10:03.66598	2012-12-07 14:38:34.390622	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
184	baap502	\N	150	1		2	24	4	\N	64	Dev	\N	2		2012-12-03 17:12:19.824012	2012-12-07 14:38:34.396159	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
185	baap503	\N	150	1		2	24	4	\N	32	Dev	\N	2		2012-12-03 17:12:47.286935	2012-12-07 14:38:34.401789	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
186	baap504	\N	150	1		2	24	4	\N	32	Dev	\N	2		2012-12-03 17:13:02.209096	2012-12-07 14:38:34.407541	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
187	baap505	\N	150	1		2	24	4	\N	32	Dev	\N	2		2012-12-03 17:13:12.718648	2012-12-07 14:38:34.413545	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
188	baap551	\N	150	1		2	24	2	\N	32	Dev	\N	2		2012-12-03 17:13:33.413568	2012-12-07 14:38:34.419027	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
189	baap552	\N	150	1		2	24	2	\N	32	Dev	\N	2		2012-12-03 17:13:44.657982	2012-12-07 14:38:34.424946	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
191	baap602	\N	150	1		2	24	4	\N	40	Dev	\N	2		2012-12-03 17:15:21.198475	2012-12-07 14:38:34.431311	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
190	baap601	\N	150	1		2	24	4	\N	32	Dev	\N	2		2012-12-03 17:14:57.363404	2012-12-07 14:38:34.438276	Application	Solaris 10	1	1	vCPU	f	\N	\N	f	\N
193	baap604	\N	150	1		2	24	4	\N	32	Dev	\N	2		2012-12-03 17:17:11.509132	2012-12-07 14:38:34.450104	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
194	baap605	\N	150	1		2	24	4	\N	32	Dev	\N	2		2012-12-03 17:17:33.542348	2012-12-07 14:38:34.456202	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
195	baap606	\N	150	1		2	24	4	\N	32	Dev	\N	2		2012-12-03 17:17:43.059906	2012-12-07 14:38:34.461692	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
196	baap607	\N	150	1		2	24	4	\N	32	Dev	\N	2		2012-12-03 17:17:51.377575	2012-12-07 14:38:34.467236	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
197	baap608	\N	150	1		2	24	4	\N	32	Dev	\N	2		2012-12-03 17:17:58.035953	2012-12-07 14:38:34.473025	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
198	bcpx520	\N	150	1		2	24	1	\N	4	Dev	\N	16		2012-12-03 17:18:51.324467	2012-12-07 14:38:34.478997	BGC Proxy VM	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
199	bcsm520	\N	150	1		2	24	1	\N	4	Dev	\N	16		2012-12-03 17:19:16.314808	2012-12-07 14:38:34.484553	BGC Proxy VM	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
202	px118	\N	\N	2	0844QBD06B	50	15	2	\N	4	Live	\N	26	192.168.232.184	2012-12-03 17:40:33.655324	2012-12-07 14:38:34.495739	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
201	px117	\N	\N	2		50	18	2	\N	2	Live	\N	26	192.168.232.180	2012-12-03 17:39:34.335506	2012-12-07 14:38:34.501154	Proxy Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
217	ifex604	\N	3	1	CZC9400T7J	2	3	8	\N	196	Dev	\N	20	10.105.255.37	2012-12-04 11:24:54.555899	2012-12-07 14:38:34.583643	Dunstable VMWare Cluster	ESX 4.1	1	\N	2.933 Ghz	f	\N	\N	f	\N
237	px217	\N	\N	1	0750AL8B24	54	18	2	\N	2	DR	\N	26	192.168.231.180	2012-12-04 13:52:38.385188	2012-12-07 14:38:34.741614	Proxy Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
231	entbl103	\N	90	2		40	3	2	\N	32	Live	\N	20		2012-12-04 12:34:16.590819	2012-12-07 14:38:34.744879	Free unused	Solaris 10	1	\N	Quad-Core Intel Xeon, 2933 MHz	f	\N	\N	f	\N
204	px120	\N	\N	2	0848QBD095	51	15	2	\N	4	Live	\N	26	192.168.232.185	2012-12-03 17:42:54.938539	2012-12-07 14:38:34.516349	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
235	px218	\N	\N	1	0844QBD06B	53	15	2	\N	4	DR	\N	26	192.168.232.184	2012-12-04 13:49:35.381648	2012-12-07 14:38:34.776745	Proxy Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
236	px220	\N	\N	1	0906QBD04A	54	15	2	\N	4	DR	\N	26	192.168.231.185	2012-12-04 13:51:06.389029	2012-12-07 14:38:34.781577	Proxy Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
203	px119	\N	\N	2	0750AL8B2A	51	18	2	\N	2	Live	\N	26	192.168.232.181	2012-12-03 17:41:51.655422	2012-12-07 14:38:34.801798	Proxy Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
205	px121	\N	\N	2	0750AL8B29	51	18	2	\N	2	Live	\N	26		2012-12-03 17:43:44.911176	2012-12-07 14:38:34.806181	Proxy Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
238	px219	\N	\N	1	0812ALA8C3	54	18	2	\N	2	DR	\N	26	192.168.231.181	2012-12-04 13:57:36.740599	2012-12-07 14:38:34.811255	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
241	px304	\N	\N	1	0750AL8B2C	56	18	1	\N	2	TT	\N	26	192.168.230.184	2012-12-04 14:03:31.474158	2012-12-07 14:38:34.840476	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
206	faap401	\N	150	1		2	24	2	\N	48	Dev	\N	11		2012-12-03 17:51:30.82029	2012-12-07 14:38:34.522812	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
207	faap402	\N	150	1		2	24	2	\N	48	Dev	\N	11		2012-12-03 17:51:41.984009	2012-12-07 14:38:34.532585	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
208	faap501	\N	150	1		2	24	2	\N	32	Dev	\N	11		2012-12-03 17:51:58.512725	2012-12-07 14:38:34.538739	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
209	faap502	\N	150	1		2	24	2	\N	32	Dev	\N	11		2012-12-03 17:52:22.385651	2012-12-07 14:38:34.544698	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
210	faap551	\N	150	1		2	24	2	\N	32	Dev	\N	11		2012-12-03 17:52:34.94255	2012-12-07 14:38:34.550698	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
211	faap552	\N	150	1		2	24	2	\N	32	Dev	\N	11		2012-12-03 17:52:43.614486	2012-12-07 14:38:34.556656	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
212	faap601	\N	150	1		2	24	2	\N	32	Dev	\N	11		2012-12-03 17:53:05.634651	2012-12-07 14:38:34.562292	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
213	faap602	\N	150	1		2	24	2	\N	32	Dev	\N	11		2012-12-03 17:53:13.409962	2012-12-07 14:38:34.567579	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
215	ifpk001	\N	150	1		2	24	2	\N	32	Dev	\N	20		2012-12-03 17:55:44.746201	2012-12-07 14:38:34.572339	Shared  dev nfast hardserver.	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
218	ifex605	\N	3	1	CZC9454KTS	2	3	8	\N	196	Dev	\N	20	10.105.255.33	2012-12-04 11:25:40.662729	2012-12-07 14:38:34.588666	Dunstable VMWare Cluster	ESX 4.1	1	\N	2.933 Ghz	f	\N	\N	f	\N
219	ifex606	\N	3	1	CZ30433NNW	2	3	8	\N	196	Dev	\N	20	10.105.255.80	2012-12-04 11:26:40.591463	2012-12-07 14:38:34.593335	Dunstable VMWare Cluster	ESX 4.1	1	\N	2.933 Ghz	f	\N	\N	f	\N
220	bcap607	\N	37	1		2	25	\N	\N	\N	Dev	\N	16		2012-12-04 11:30:35.597607	2012-12-07 14:38:34.614654	Application	Solaris 10	1	\N		f	\N	\N	f	\N
221	bcpx606	\N	37	1		2	25	\N	\N	\N	Dev	\N	16		2012-12-04 11:31:02.375533	2012-12-07 14:38:34.619704	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
222	bcpx607	\N	37	1		2	25	\N	\N	\N	Dev	\N	16		2012-12-04 11:31:14.956148	2012-12-07 14:38:34.624696	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
223	bcap606	\N	37	1		2	25	\N	\N	\N	Dev	\N	16		2012-12-04 11:31:28.326609	2012-12-07 14:38:34.647198	Application	Solaris 10	1	\N		f	\N	\N	f	\N
101	bcpx602	t	1	1		1	25	\N	\N	\N	Dev	\N	16		2012-11-30 11:38:55.959511	2012-12-07 14:38:34.652659	Proxy Server	Solaris 10	1	1		f	\N	\N	f	\N
224	dvzz603	\N	\N	1	BCF0937055	36	21	4	\N	96	Dev	\N	20	10.105.255.12	2012-12-04 12:01:52.536887	2012-12-07 14:38:34.657731	Zone Server	Solaris 10	2	\N	QuadCore-2.53GHz + 2 x QuadCore-2.4GHz (16 Cores)	f	\N	\N	f	\N
225	bcdb401	\N	224	1		36	25	\N	\N	\N	CR	\N	16		2012-12-04 12:05:22.825964	2012-12-07 14:38:34.680172	DB	Solaris 10	2	\N		f	\N	\N	f	\N
226	bcdb501	\N	224	1		36	25	\N	\N	\N	UAT	\N	16		2012-12-04 12:06:10.426308	2012-12-07 14:38:34.683888	DB	Solaris 10	2	\N		f	\N	\N	f	\N
227	ifzz101	\N	90	2	czc003244m	40	3	2	\N	32	Live	\N	20		2012-12-04 12:29:36.431134	2012-12-07 14:38:34.687495	Zone Server - Netbackup Master Server + Ops Center	Solaris 10	1	\N	Quad-Core Intel Xeon, 2933 MHz	f	\N	\N	f	\N
230	spzz106	\N	90	2	czz20112xcr	40	3	2	\N	38	Live	\N	21		2012-12-04 12:32:19.035064	2012-12-07 14:38:34.710312	Zones - SP App Server - Integrator & Sentinel	Solaris 10	1	\N	Quad-Core Intel Xeon, 2933 MHz	f	\N	\N	f	\N
229	spzz105	\N	90	2	cz20112xch	40	3	2	\N	38	Live	\N	21		2012-12-04 12:31:34.48753	2012-12-07 14:38:34.733032	Zones - SP App Server - WebSphere MQ  & Interchange	Solaris 10	1	1	Quad-Core Intel Xeon, 2933 MHz	f	\N	\N	f	\N
232	ifzz102	\N	91	2	cz20060b5w	41	3	2	\N	32	Live	\N	20		2012-12-04 12:36:29.753991	2012-12-07 14:38:34.748631	Netbackup RMAN DB server	Solaris 10	1	\N	Quad-Core Intel Xeon, 2933 MHz	f	\N	\N	f	\N
233	spzz102	\N	91	2	cz2014427h	41	3	2	\N	38	Live	\N	21		2012-12-04 12:37:48.501017	2012-12-07 14:38:34.751696	Zones - VPS DB - Distra	Solaris 10	1	\N	Quad-Core Intel Xeon, 2933 MHz	f	\N	\N	f	\N
234	px216	\N	\N	1	0848QBD05E	53	15	2	\N	4	DR	\N	26	192.168.231.180	2012-12-04 13:48:02.299597	2012-12-07 14:38:34.771854	Proxy Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
239	px221	\N	\N	1	0812ALA8C6	53	18	2	\N	2	DR	\N	26	192.168.231.182	2012-12-04 13:58:21.156683	2012-12-07 14:38:34.816281	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
240	px302	\N	\N	1	0750AL8B25	55	18	1	\N	2	TT	\N	26	192.168.230.183	2012-12-04 14:01:28.058037	2012-12-07 14:38:34.834881	Proxy Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
242	px306	\N	\N	1	0642TU10U6	56	26	1	\N	2	TT	\N	26	192.168.230.185	2012-12-04 14:05:25.474607	2012-12-07 14:38:34.845346	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
244	px401	\N	\N	1	0642TU10U1	56	26	1	\N	2	SUT	\N	26	Serial	2012-12-04 14:31:20.986375	2012-12-07 14:38:34.865523	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
245	px402	\N	\N	1	0642TU300F	55	26	1	\N	2	SUT	\N	26	Serial	2012-12-04 14:31:59.103267	2012-12-07 14:38:34.871523	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
246	px404	\N	\N	1	0749AL8841	57	18	1	\N	2	Dev	\N	26	Serial	2012-12-04 14:33:21.727489	2012-12-07 14:38:34.875772	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
247	px501	\N	\N	1	0642TU10TZ	56	26	1	\N	2	SS	\N	26	Serial	2012-12-04 14:34:47.680213	2012-12-07 14:38:34.896296	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
216	ifex603	\N	3	1	CZC94785G4	2	3	8	\N	196	Dev	\N	20	ilo 10.105.255.36	2012-12-04 11:23:52.527919	2012-12-07 14:38:34.900732	Dunstable VMWare Cluster	ESX 4.1	1	1	2.933 Ghz	f	\N	\N	f	\N
254	bczz503	\N	\N	1	0947QBU003	36	7	2	\N	16	UAT	\N	16		2012-12-04 17:21:22.310466	2012-12-07 14:38:34.958266	Zone Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
257	badb512	\N	75	1		38	25	\N	\N	\N	UAT	\N	2		2012-12-04 17:57:51.246275	2012-12-07 14:38:34.972885	DB	Solaris 10	1	\N		f	\N	\N	f	\N
269	bcap501	\N	252	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:22:54.193894	2012-12-07 14:38:35.090152	Application	Solaris 10	1	1		f	\N	\N	f	\N
270	bcap502	\N	252	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:23:04.781497	2012-12-07 14:38:35.09521	Application	Solaris 10	1	1		f	\N	\N	f	\N
271	bcap503	\N	252	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:23:11.829818	2012-12-07 14:38:35.115117	Application	Solaris 10	1	1		f	\N	\N	f	\N
272	bcap504	\N	252	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:23:20.944583	2012-12-07 14:38:35.120197	Application	Solaris 10	1	1		f	\N	\N	f	\N
273	decl501	\N	252	1		63	25	\N	\N	\N	UAT	\N	13		2012-12-04 18:23:53.030099	2012-12-07 14:38:35.125188	ETS/STS Client	Solaris 10	1	1		f	\N	\N	f	\N
275	bcpx501	\N	253	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:26:37.934691	2012-12-07 14:38:35.137289	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
249	bcpx301	\N	\N	1	0821QAU01C	39	7	2	\N	4	TT	\N	16		2012-12-04 17:12:02.627188	2012-12-07 14:38:34.928278	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
250	bcpx302	\N	\N	1	0821QAU005	38	7	2	\N	4	TT	\N	16		2012-12-04 17:12:56.311952	2012-12-07 14:38:34.933544	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
313	spap403	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:22:04.946302	2012-12-07 14:38:35.39265	Application	Solaris 10	1	\N		f	\N	\N	f	\N
251	bcpx303	\N	\N	1	0822QAU045	39	7	2	\N	4	TT	\N	16		2012-12-04 17:13:42.32655	2012-12-07 14:38:34.940849	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
253	bczz502	\N	\N	1	0804QAD021	63	15	1	\N	16	UAT	\N	16	10.100.81.169	2012-12-04 17:18:35.833566	2012-12-07 14:38:34.945938	Zone Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
252	bczz501	\N	\N	1	0818QAU090	63	7	4	\N	128	UAT	\N	16		2012-12-04 17:16:12.080919	2012-12-07 14:38:34.950853	Zone Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 8224	f	\N	\N	f	\N
256	ifdb302	\N	\N	1	0725AN1154	63	14	4	\N	16	TT	\N	20	10.104.204.11	2012-12-04 17:29:00.122677	2012-12-07 14:38:34.963091	Unused presently but BACS/FPS has dibs on	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
255	ifdb301	\N	\N	1	0725AN1548	39	14	4	\N	16	TT	\N	20	10.104.204.9	2012-12-04 17:26:12.747416	2012-12-07 14:38:34.967965	Unused presently but BACS/FPS has dibs on	Solaris 10	1	1	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
258	baor511	\N	75	1		38	25	\N	\N	\N	UAT	\N	2		2012-12-04 17:58:32.161839	2012-12-07 14:38:34.9792	Oracle Reports Server	Solaris 10	1	\N		f	\N	\N	f	\N
259	dedb501	\N	75	1		38	25	\N	\N	\N	UAT	\N	13		2012-12-04 17:59:06.558659	2012-12-07 14:38:34.984123	DB	Solaris 10	1	\N		f	\N	\N	f	\N
260	dedb511	\N	75	1		38	25	\N	\N	\N	UAT	\N	13		2012-12-04 17:59:21.396729	2012-12-07 14:38:34.991784	DB	Solaris 10	1	\N		f	\N	\N	f	\N
261	fdb504	\N	75	1		38	25	\N	\N	\N	UAT	\N	11		2012-12-04 17:59:45.3851	2012-12-07 14:38:34.996905	DB	Solaris 10	1	\N		f	\N	\N	f	\N
262	badb402	\N	224	1		36	25	\N	\N	\N	CR	\N	2		2012-12-04 18:19:31.208126	2012-12-07 14:38:35.002174	DB	Solaris 10	1	\N		f	\N	\N	f	\N
263	bcdb503	\N	224	1		36	25	\N	\N	\N	CR	\N	16		2012-12-04 18:20:15.463119	2012-12-07 14:38:35.021061	DB	Solaris 10	1	\N		f	\N	\N	f	\N
264	bcdb504	\N	224	1		36	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:20:30.616125	2012-12-07 14:38:35.026685	DB	Solaris 10	1	\N		f	\N	\N	f	\N
265	bcdb505	\N	224	1		36	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:20:41.577151	2012-12-07 14:38:35.032468	DB	Solaris 10	1	\N		f	\N	\N	f	\N
266	bcdb506	\N	224	1		36	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:20:49.293511	2012-12-07 14:38:35.052045	DB	Solaris 10	1	\N		f	\N	\N	f	\N
267	bcdb507	\N	224	1		36	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:20:58.124725	2012-12-07 14:38:35.057304	DB	Solaris 10	1	\N		f	\N	\N	f	\N
274	deap501	\N	252	1		63	25	\N	\N	\N	UAT	\N	13		2012-12-04 18:24:07.191497	2012-12-07 14:38:35.085153	Application	Solaris 10	1	1		f	\N	\N	f	\N
276	bcpx502	\N	253	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:26:47.663509	2012-12-07 14:38:35.142674	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
277	bcpx503	\N	253	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:26:54.765154	2012-12-07 14:38:35.148485	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
278	bcpx504	\N	253	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:27:01.476112	2012-12-07 14:38:35.15463	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
279	bcpx505	\N	253	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:27:08.41366	2012-12-07 14:38:35.159683	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
280	bcpx506	\N	253	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:27:16.293827	2012-12-07 14:38:35.165068	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
281	bcpx507	\N	253	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:27:25.358854	2012-12-07 14:38:35.171084	Proxy Server	Solaris 10	1	\N		f	\N	\N	f	\N
282	bcsm501	\N	253	1		63	25	\N	\N	\N	UAT	\N	16		2012-12-04 18:27:48.82987	2012-12-07 14:38:35.176597	Simulation Zone	Solaris 10	1	\N		f	\N	\N	f	\N
287	ipap601	\N	150	1		2	24	4	\N	32	Dev	\N	23		2012-12-05 13:03:35.481615	2012-12-07 14:38:35.203674	Application	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
288	ipap602	\N	150	1		2	24	4	\N	32	Dev	\N	23		2012-12-05 13:03:53.584723	2012-12-07 14:38:35.209651	Application	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
289	ipap603	\N	150	1		2	24	4	\N	32	Dev	\N	23		2012-12-05 13:04:07.351323	2012-12-07 14:38:35.21531	Application	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
290	ipap604	\N	150	1		2	24	4	\N	32	Dev	\N	23		2012-12-05 13:04:20.808816	2012-12-07 14:38:35.221704	Application	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
291	ipap605	\N	150	1		2	24	4	\N	32	Dev	\N	23		2012-12-05 13:04:31.485037	2012-12-07 14:38:35.227515	Application	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
292	ipap606	\N	150	1		2	24	4	\N	32	Dev	\N	23		2012-12-05 13:04:39.267637	2012-12-07 14:38:35.232852	Application	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
214	ippk611	\N	150	1		2	24	2	\N	8	Dev	\N	23		2012-12-03 17:53:58.913779	2012-12-07 14:38:35.238324	IPS nfast hardserver.	Solaris 10	1	1	vCPU	f	\N	\N	f	\N
293	bcap401	\N	254	1		36	25	\N	\N	\N	CR	\N	16		2012-12-05 13:58:16.55383	2012-12-07 14:38:35.243782	Application	Solaris 10	1	\N		f	\N	\N	f	\N
294	bcap505	\N	254	1		36	25	\N	\N	\N	UAT	\N	16		2012-12-05 13:58:38.677652	2012-12-07 14:38:35.248925	Application	Solaris 10	1	\N		f	\N	\N	f	\N
295	bcap506	\N	254	1		36	25	\N	\N	\N	UAT	\N	16		2012-12-05 13:58:52.027405	2012-12-07 14:38:35.253887	Application	Solaris 10	1	\N		f	\N	\N	f	\N
296	bcap507	\N	254	1		36	25	\N	\N	\N	UAT	\N	16		2012-12-05 13:59:01.105667	2012-12-07 14:38:35.259616	Application	Solaris 10	1	\N		f	\N	\N	f	\N
336	spap305	\N	335	1		42	25	\N	\N	\N	TT	\N	21		2012-12-07 11:13:46.097145	2012-12-07 14:38:35.513566	Application	Solaris 10	1	\N		f	\N	\N	f	\N
344	asdb101	\N	\N	3	0809ALA1BB	65	17	2	\N	8	Live	\N	15		2012-12-07 11:21:18.969708	2012-12-07 14:38:35.553718	AMS WP DataBase Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 - 2.8GHz	f	\N	\N	f	\N
352	spzz303	\N	92	1	CZ201440RV	42	3	2	\N	38	TT	\N	21		2012-12-07 12:31:36.532318	2012-12-07 14:38:35.600096	Zone Server	Solaris 10	1	\N	Quad-Core Intel Xeon, 2933 MHz	f	\N	\N	f	\N
24	ap106	\N	\N	2	0645NNN0EU	21	6	1	\N	32	Live	\N	17	10.129.2.68, telnet from 10.129.2.x 	2012-11-27 14:26:37.853673	2012-12-07 14:38:33.272932	STS/ETS App server	Solaris 10	1	1	UltraSPARC-T1 (8 Cores) 1.2GHz 	f	\N	\N	f	\N
286	ifex612	\N	3	1	CZC9400T7Q	2	3	8	\N	196	Dev	\N	20	10.105.255.25	2012-12-05 13:02:16.089989	2012-12-14 12:13:32.176751	Dunstable VMWare Cluster	ESX 4.1	1	1	2.933 Ghz	f	\N	\N	f	\N
268	dedb401	\N	224	1		36	25	\N	\N	\N	CR	\N	13		2012-12-04 18:21:18.275517	2012-12-21 11:30:55.449101	DB	Solaris 10	1	1		f	\N	\N	f	\N
297	asdb611	\N	5	1		63	25	\N	\N	\N	Dev	\N	15		2012-12-05 14:27:59.988038	2012-12-21 14:23:06.15994	DB	Solaris 10	1	\N		f	\N	\N	f	\N
298	badb601	\N	5	1		63	25	\N	\N	\N	Dev	\N	2		2012-12-05 14:37:49.218523	2012-12-21 14:23:06.166819	DB	Solaris 10	1	\N		f	\N	\N	f	\N
299	badb602	\N	5	1		63	25	\N	\N	\N	Dev	\N	2		2012-12-05 15:34:08.055981	2012-12-21 14:23:06.172094	DB	Solaris 10	1	\N		f	\N	\N	f	\N
300	badb603	\N	5	1		63	25	\N	\N	\N	Dev	\N	2		2012-12-05 15:34:21.775198	2012-12-21 14:23:06.178291	DB	Solaris 10	1	\N		f	\N	\N	f	\N
301	baor601	\N	5	1		63	25	\N	\N	\N	Dev	\N	2		2012-12-05 15:34:46.384505	2012-12-21 14:23:06.184263	Oracle Reports Server	Solaris 10	1	\N		f	\N	\N	f	\N
303	bcdb602	\N	5	1		63	25	\N	\N	\N	Dev	\N	16		2012-12-05 15:35:15.345401	2012-12-21 14:23:06.189782	DB	Solaris 10	1	\N		f	\N	\N	f	\N
304	dedb601	\N	5	1		63	25	\N	\N	\N	Dev	\N	13		2012-12-05 15:35:38.287853	2012-12-21 14:23:06.194827	DB	Solaris 10	1	\N		f	\N	\N	f	\N
305	fdb601	\N	5	1		63	25	\N	\N	\N	Dev	\N	11		2012-12-05 15:35:56.237529	2012-12-21 14:23:06.20007	DB	Solaris 10	1	\N		f	\N	\N	f	\N
306	fdb602	\N	5	1		63	25	\N	\N	\N	Dev	\N	11		2012-12-05 15:36:06.539556	2012-12-21 14:23:06.206023	DB	Solaris 10	1	\N		f	\N	\N	f	\N
308	mpdb601	\N	5	1		63	25	\N	\N	\N	Dev	\N	22		2012-12-05 15:36:32.973968	2012-12-21 14:23:06.211174	DB	Solaris 10	1	\N		f	\N	\N	f	\N
309	mpdb611	\N	5	1		63	25	\N	\N	\N	Dev	\N	22		2012-12-05 15:36:45.396984	2012-12-21 14:23:06.217536	DB	Solaris 10	1	\N		f	\N	\N	f	\N
310	spdb601	\N	5	1		63	25	\N	\N	\N	Dev	\N	21		2012-12-05 15:38:18.790433	2012-12-21 14:23:06.223045	DB	Solaris 10	1	\N		f	\N	\N	f	\N
68	baap302	\N	\N	1	1002QBU014	36	7	4	\N	128	TT	\N	2	10.104.255.67 	2012-11-29 15:10:39.980094	2012-12-07 14:38:33.587775	Application - Online	Solaris 10	1	1	6-Core AMD Opteron 8439 2.8GHz  CPU  	f	\N	\N	f	\N
117	spap603	t	1	1		1	25	\N	\N	\N	Dev	\N	21	\N	2012-11-30 13:02:45.082549	2012-12-07 14:38:35.364162	Application Server	Solaris 10	1	1	\N	f	\N	\N	f	\N
311	spap401	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:21:02.292658	2012-12-07 14:38:35.37556	Application	Solaris 10	1	\N		f	\N	\N	f	\N
312	spap402	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:21:30.337988	2012-12-07 14:38:35.386692	Application	Solaris 10	1	\N		f	\N	\N	f	\N
314	spap404	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:22:58.050975	2012-12-07 14:38:35.397986	Application	Solaris 10	1	\N		f	\N	\N	f	\N
315	spap405	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:23:12.785845	2012-12-07 14:38:35.403125	Application	Solaris 10	1	\N		f	\N	\N	f	\N
316	spap406	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:23:25.625794	2012-12-07 14:38:35.408751	Application	Solaris 10	1	\N		f	\N	\N	f	\N
317	spap408	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:23:39.644547	2012-12-07 14:38:35.414138	Application	Solaris 10	1	\N		f	\N	\N	f	\N
318	spap501	\N	36	1		2	4	\N	\N	\N	UAT	\N	21		2012-12-06 13:36:19.550195	2012-12-07 14:38:35.419333	Application	Solaris 10	1	\N		f	\N	\N	f	\N
319	spap502	\N	36	1		2	4	\N	\N	\N	UAT	\N	21		2012-12-06 13:36:38.664267	2012-12-07 14:38:35.424655	Application	Solaris 10	1	\N		f	\N	\N	f	\N
320	spap503	\N	36	1		2	4	\N	\N	\N	UAT	\N	21		2012-12-06 13:36:47.469924	2012-12-07 14:38:35.429322	Application	Solaris 10	1	\N		f	\N	\N	f	\N
321	spap504	\N	36	1		2	4	\N	\N	\N	UAT	\N	21		2012-12-06 13:36:55.161904	2012-12-07 14:38:35.434165	Application	Solaris 10	1	\N		f	\N	\N	f	\N
322	spap505	\N	36	1		2	4	\N	\N	\N	UAT	\N	21		2012-12-06 13:37:06.250054	2012-12-07 14:38:35.439305	Application	Solaris 10	1	\N		f	\N	\N	f	\N
323	spap506	\N	36	1		2	4	\N	\N	\N	UAT	\N	21		2012-12-06 13:37:16.223256	2012-12-07 14:38:35.444098	Application	Solaris 10	1	\N		f	\N	\N	f	\N
324	spcl401	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:37:59.226918	2012-12-07 14:38:35.448883	ETS/STS Client	Solaris 10	1	\N		f	\N	\N	f	\N
325	spcl501	\N	36	1		2	4	\N	\N	\N	UAT	\N	21		2012-12-06 13:38:14.427437	2012-12-07 14:38:35.453672	ETS/STS Client	Solaris 10	1	\N		f	\N	\N	f	\N
326	spdb401	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:38:57.796649	2012-12-07 14:38:35.458296	DB	Solaris 10	1	\N		f	\N	\N	f	\N
327	spdb402	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:39:06.55569	2012-12-07 14:38:35.463202	DB	Solaris 10	1	\N		f	\N	\N	f	\N
328	spdb403	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:39:15.774521	2012-12-07 14:38:35.471059	DB	Solaris 10	1	\N		f	\N	\N	f	\N
329	spdb408	\N	36	1		2	4	\N	\N	\N	CR	\N	21		2012-12-06 13:39:28.247209	2012-12-07 14:38:35.476241	DB	Solaris 10	1	\N		f	\N	\N	f	\N
330	spdb501	\N	36	1		2	4	\N	\N	\N	UAT	\N	21		2012-12-06 13:39:40.333726	2012-12-07 14:38:35.481089	DB	Solaris 10	1	\N		f	\N	\N	f	\N
331	spdb502	\N	36	1		2	4	\N	\N	\N	UAT	\N	21		2012-12-06 13:39:50.765069	2012-12-07 14:38:35.488503	DB	Solaris 10	1	\N		f	\N	\N	f	\N
332	spdb503	\N	36	1		2	4	\N	\N	\N	UAT	\N	21		2012-12-06 13:40:01.710554	2012-12-07 14:38:35.493297	DB	Solaris 10	1	\N		f	\N	\N	f	\N
334	rddb601	\N	\N	1	0637AN1419	64	14	4	\N	16	Dev	\N	23	10.105.2.41	2012-12-06 13:46:46.457901	2012-12-07 14:38:35.503234	DB	Solaris 10	2	\N	1800MHz UltraSPARC-IV+ (8 cores)	f	\N	\N	f	\N
335	spzz301	\N	92	1	CZ20101Y3P	42	3	2	\N	38	TT	\N	21		2012-12-07 10:33:53.874259	2012-12-07 14:38:35.508333	Zone Server	Solaris 10	1	1	Quad-Core Intel Xeon, 2933 MHz	f	\N	\N	f	\N
337	spap306	\N	335	1		42	25	\N	\N	\N	TT	\N	21		2012-12-07 11:13:53.80155	2012-12-07 14:38:35.518122	Application	Solaris 10	1	\N		f	\N	\N	f	\N
338	spap307	\N	335	1		42	25	\N	\N	\N	TT	\N	21		2012-12-07 11:14:02.446916	2012-12-07 14:38:35.523269	Application	Solaris 10	1	\N		f	\N	\N	f	\N
339	spcl301	\N	335	1		42	25	\N	\N	\N	TT	\N	21		2012-12-07 11:14:27.67339	2012-12-07 14:38:35.52815	ETS/STS Client	Solaris 10	1	\N		f	\N	\N	f	\N
340	asap101	\N	\N	3	0809ALA30B	65	17	2	\N	8	Live	\N	15		2012-12-07 11:17:23.167344	2012-12-07 14:38:35.533057	AMS WP Appication Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 - 2.8GHz	f	\N	\N	f	\N
341	asap102	\N	\N	3	0809ALA183	65	17	2	\N	8	Live	\N	15		2012-12-07 11:17:48.537951	2012-12-07 14:38:35.537996	AMS WP Appication Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 - 2.8GHz	f	\N	\N	f	\N
343	asap202	\N	\N	5	0809ALA228	66	17	2	\N	8	DR	\N	15		2012-12-07 11:19:05.26994	2012-12-07 14:38:35.543323	AMS WP Appication Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2218 HE - 1.6GHz	f	\N	\N	f	\N
342	asap201	\N	\N	5	0809ALA22B	66	17	2	\N	8	DR	\N	15		2012-12-07 11:18:18.149882	2012-12-07 14:38:35.54875	AMS WP Appication Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2220 - 2.8GHz	f	\N	\N	f	\N
345	asdb201	\N	\N	5	0809ALA1B6	66	17	2	\N	8	DR	\N	15		2012-12-07 11:21:53.043762	2012-12-07 14:38:35.558704	AMS WP DataBase Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 - 2.8GHz	f	\N	\N	f	\N
346	aspx101	\N	\N	3	0810ALA433	65	18	2	\N	4	Live	\N	15		2012-12-07 11:23:35.708405	2012-12-07 14:38:35.564037	AMS WP Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 - 2.8GHz	f	\N	\N	f	\N
347	aspx202	\N	\N	5	0810ALA4C2	66	18	2	\N	4	DR	\N	15		2012-12-07 11:40:04.187262	2012-12-07 14:38:35.570019	AMS WP Proxy Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2218 HE - 1.6GHz	f	\N	\N	f	\N
355	spap317	\N	352	1		42	25	\N	\N	\N	TT	\N	21		2012-12-07 12:35:23.650702	2012-12-07 14:38:35.575007	Application		1	\N		f	\N	\N	f	\N
350	entbc301	\N	\N	1		42	2	\N	\N	\N	TT	\N	20		2012-12-07 12:00:17.345818	2012-12-07 14:38:35.585238	Blade Enclosure		1	\N		f	\N	\N	f	\N
351	entbc302	\N	\N	1		43	2	\N	\N	\N	TT	\N	20		2012-12-07 12:00:36.911875	2012-12-07 14:38:35.590032	Blade Enclosure		1	\N		f	\N	\N	f	\N
348	aspx601	\N	\N	3	0818QAD009	67	15	2	\N	4	Dev	\N	15		2012-12-07 11:41:56.087854	2012-12-07 14:38:35.595038	AMS WP Web/Proxy Server	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2218 HE - 1.6GHz  - 2.8GHz	f	\N	\N	f	\N
353	spap315	\N	352	1		42	25	\N	\N	\N	TT	\N	21		2012-12-07 12:35:07.396348	2012-12-07 14:38:35.605497	Application		1	\N		f	\N	\N	f	\N
354	spap316	\N	352	1		42	25	\N	\N	\N	TT	\N	21		2012-12-07 12:35:14.957396	2012-12-07 14:38:35.610321	Application		1	\N		f	\N	\N	f	\N
357	ss202	\N	\N	1	0541AL6074	70	31	4	\N	16	SS	\N	14	termserv_sutss user: platform	2012-12-07 14:03:39.47842	2012-12-07 14:38:35.615313	Solutions Suppliers	Solaris 8	1	\N	UltraSPARC-IIIi 1.5GHz	f	\N	\N	f	\N
356	ss201	\N	\N	1	248Q01B2	69	30	4	\N	32	SS	\N	14	termserv_sutss user: platform	2012-12-07 13:48:18.883947	2012-12-07 14:38:35.620249	Pre-prod (?)	Solaris 8	1	1	900Mhz	f	\N	\N	f	\N
165	ipap665	\N	150	1		2	24	2	\N	5	Dev	\N	23		2012-12-03 17:00:33.832141	2012-12-07 14:38:34.278693	Developer VM	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
200	px116	\N	\N	2	0848QBD094	50	15	2	\N	4	Live	\N	26	192.168.232.183	2012-12-03 17:34:33.37251	2012-12-07 14:38:34.490127	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
228	spzz101	\N	90	2	cz20112xc8	40	3	2	\N	38	Live	\N	21		2012-12-04 12:30:45.63329	2012-12-07 14:38:34.578315	Zones - VPS Application - Distra	Solaris 10	1	1	Quad-Core Intel Xeon, 2933 MHz	f	\N	\N	f	\N
248	px502	\N	\N	1	0637TU303C	55	26	1	\N	2	SS	\N	26		2012-12-04 14:35:23.460199	2012-12-07 14:38:34.905666	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2210 - 1.8GHz	f	\N	\N	f	\N
121	cm303	\N	\N	1	0747AL8385	1	17	2	\N	8	Dev	\N	24	10.105.2.237	2012-11-30 13:08:57.531417	2012-12-07 14:38:35.369771	Configuration Management	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz) 	f	\N	\N	f	\N
333	decl401	\N	36	1		2	25	\N	\N	\N	CR	\N	13		2012-12-06 13:41:39.022605	2012-12-21 11:18:46.369153	ETS/STS Client	Solaris 10	1	1		f	\N	\N	f	\N
307	fdb603	\N	5	1		63	25	\N	\N	\N	Dev	\N	11		2012-12-05 15:36:16.405895	2012-12-21 14:23:06.228695	DB	Solaris 10	1	\N		f	\N	\N	f	\N
349	dvams600	\N	\N	3	0826QAU015	67	7	4	\N	32	Dev	\N	15		2012-12-07 11:44:20.199056	2012-12-07 14:38:35.580145	AMS WP Application Server & Database Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8224 - 3.2Ghz	f	\N	\N	f	\N
358	ssdb201	\N	\N	1	0423AL0A3C	15	31	4	\N	16	SS	\N	14	termserv_sutss user: platform	2012-12-07 15:48:40.215399	2012-12-07 15:49:10.215242	Database	Solaris 10	1	\N	1200MHz (sparc-IIIi) (4 Cores)	t	\N	\N	f	\N
359	ssdb202	\N	\N	1	0611AL0985	71	31	4	\N	30	SS	\N	14	termserv_sutss user: platform	2012-12-07 15:59:19.536532	2012-12-07 15:59:35.629873	Database	Solaris 10	1	\N	UltraSPARC-IIIi 1.5GHz (4 Cores)	t	\N	\N	f	\N
360	ssor201	\N	\N	1	0425AL0E72	15	31	4	\N	8	SS	\N	14	termserv_sutss user: platform	2012-12-07 16:35:14.672577	2012-12-07 16:53:48.564747	Oracle Reports Server	Solaris 8	1	\N	1000MHz	f	\N	\N	f	\N
400	bcpx102	\N	\N	2	0822QAU02E	48	15	2	\N	4	Live	\N	16	192.168.232.124	2012-12-21 12:02:40.183208	2012-12-21 12:02:40.183208	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
361	ssor202	\N	\N	1	0615AL0C00	15	31	4	\N	8	SS	\N	14	termserv_sutss user: platform	2012-12-07 16:36:05.357161	2012-12-07 16:53:48.573683	Oracle Reports Server	Solaris 8	1	\N	UltraSPARC-IIIi 1.5GHz	f	\N	\N	f	\N
362	em101	\N	\N	2	TN40530863	72	32	2	\N	2	Live	\N	14	termserv_deb user: platform	2012-12-07 16:41:20.687745	2012-12-07 16:53:48.603616	EM	Solaris 10	1	\N	UltraSPARC-IIIi 1.34GHz	f	\N	\N	f	\N
364	if106	\N	\N	2	CF22000558	72	34	1	\N	0	Live	\N	19	termserv_deb user: platform	2012-12-07 16:45:26.573036	2012-12-07 16:53:48.616063	Radius	Solaris 8	1	\N	500MHz	f	\N	\N	f	\N
366	if201	\N	\N	1	207Z0011	73	35	2	\N	2	DR	\N	19	termserv_dun Raritan user: platform	2012-12-07 16:47:32.514722	2012-12-07 16:53:48.645937	Columbus archiving	Solaris 8	1	\N	1200MHz	f	\N	\N	f	\N
365	if107	\N	\N	2	CF22000698	72	34	1	\N	0	Live	\N	19	termserv_deb user: platform	2012-12-07 16:46:21.017612	2012-12-07 16:59:41.155861	Radius	Solaris 8	1	1	500MHz	f	\N	\N	f	\N
367	cm302oradb	\N	120	1		1	4	\N	\N	\N	Dev	\N	24		2012-12-10 12:38:23.817489	2012-12-10 12:40:19.336833	CM ECSTOOLs oradb	Solaris 10	1	\N		f	\N	\N	f	\N
4	ifex601	\N	3	1	CZC9481JZ1	2	3	8	\N	196	Dev	\N	20	10.105.255.38	2012-11-23 15:29:00.75092	2012-12-14 12:11:30.983154	Dunstable VMWare Cluster	ESX 4.1	1	1	2.933 Ghz	f	\N	\N	f	\N
283	ifex609	\N	3	1	CZC9400T7N	2	3	8	\N	196	Dev	\N	20	10.105.255.22	2012-12-05 13:00:15.796542	2012-12-14 12:12:11.277882	Dunstable VMWare Cluster	ESX 4.1	1	1	2.933 Ghz	f	\N	\N	f	\N
284	ifex610	\N	3	1	CZC9400T7S	2	3	8	\N	196	Dev	\N	20	10.105.255.23	2012-12-05 13:00:53.499935	2012-12-14 12:12:38.813163	Dunstable VMWare Cluster	ESX 4.1	1	1	2.933 Ghz	f	\N	\N	f	\N
285	ifex611	\N	3	1	CZC9400T7G	2	3	8	\N	196	Dev	\N	20	10.105.255.24	2012-12-05 13:01:25.033233	2012-12-14 12:13:08.669804	Dunstable VMWare Cluster	ESX 4.1	1	1	2.933 Ghz	f	\N	\N	f	\N
131	aszz600	\N	\N	3	1110FMM1EU	46	22	1	\N	24	Dev	\N	25	172.30.255.45 from DevVDI	2012-12-03 10:19:08.071266	2012-12-14 13:04:33.127121	AMS WP Web Server / TA Proxy Server - Dev & Test	Solaris 10	1	6	6 core Intel Xeon X5670@2.93GHx	f	\N	\N	f	\N
368	enbc601	\N	\N	1	FOX1536GCCN	75	36	\N	\N	\N	Dev	\N	20	http://10.105.33.22	2012-12-19 14:40:26.025992	2012-12-19 14:40:26.025992	Blade Enclosure	None	1	\N		f	\N	\N	f	\N
369	enbc602	\N	\N	1	FOX1452GE7U	75	36	\N	\N	\N	Dev	\N	20	http://10.105.33.22	2012-12-19 14:41:03.156477	2012-12-19 14:41:03.156477	Blade Enclosure	None	1	\N		f	\N	\N	f	\N
371	apap601	\N	370	1		75	24	2	\N	4	Dev	\N	27	vsphere client to vspr448	2012-12-20 11:32:21.770143	2012-12-20 11:32:21.770143	Subversion	RHEL 6.3	1	\N	vCPU	f	\N	\N	f	\N
374	apap604	\N	370	1		75	24	2	\N	4	Dev	\N	27	vsphere client to vspr448	2012-12-20 11:34:20.530234	2012-12-20 11:34:20.530234	Nexus	RHEL 6.3	1	\N	vCPU	f	\N	\N	f	\N
375	apap605	\N	370	1		75	24	2	\N	4	Dev	\N	27	vsphere client to vspr448	2012-12-20 11:34:58.310448	2012-12-20 11:34:58.310448	Crowd LDAP	RHEL 6.3	1	\N	vCPU	f	\N	\N	f	\N
376	apdb601	\N	370	1		75	24	4	\N	8	Dev	\N	27	vsphere client to vspr448	2012-12-20 11:35:47.23456	2012-12-20 11:35:47.23456	Postgres DB	RHEL 6.3	1	\N	vCPU	f	\N	\N	f	\N
372	apap602	\N	370	1		75	24	2	\N	8	Dev	\N	27	vsphere client to vspr448	2012-12-20 11:33:11.123326	2012-12-20 11:36:09.121704	Jira, Confluence, Greenhopper	RHEL 6.3	1	1	vCPU	f	\N	\N	f	\N
373	apap603	\N	370	1		75	24	2	\N	8	Dev	\N	27	vsphere client to vspr448	2012-12-20 11:33:52.82492	2012-12-20 11:36:18.855169	Bamboo, Maven, Clover,  Fisheye, Crucible, Tomcat	RHEL 6.3	1	1	vCPU	f	\N	\N	f	\N
370	DUNSTABLE-2	\N	369	1		75	23	24	\N	96	Dev	\N	20	vsphere client to vspr448	2012-12-20 11:29:36.5568	2012-12-20 11:36:36.510971	vsphere cluster	ESX 4.1	1	1	2.67 GHz	f	\N	\N	f	\N
377	ca101	\N	\N	2	TF40341787	76	37	1	\N	1	Live	\N	19	termserv_deb user: platform	2012-12-20 17:59:58.593353	2012-12-20 17:59:58.593353	Certificate Authority Server	Solaris 8	1	\N	650 MHz	f	\N	\N	f	\N
378	ca201	\N	\N	1	TF40342041	77	37	1	\N	1	Live	\N	19	termserv_dun Raritan user: platform	2012-12-20 18:01:26.026948	2012-12-20 18:01:26.026948	Certificate Authority Server	Solaris 8	1	\N	650 MHz	f	\N	\N	f	\N
379	db103	\N	\N	2	BCF0821058	78	21	4	\N	16	Live	\N	19	xscf 10.129.255.29	2012-12-20 18:07:58.934431	2012-12-20 18:07:58.934431	sec0 - Database	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI	f	\N	\N	f	\N
380	db104	\N	\N	2	BCF082005H	79	21	4	\N	16	Live	\N	19	10.129.255.30	2012-12-20 18:08:50.57141	2012-12-20 18:08:50.57141	sec0 - Database	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI	f	\N	\N	f	\N
381	db105	\N	\N	2	BCF082105J	78	21	4	\N	16	Live	\N	19	xscf 10.129.255.31	2012-12-20 18:09:52.612757	2012-12-20 18:09:52.612757	sec0 - Database	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI	f	\N	\N	f	\N
382	db203	\N	\N	1	BCF0821054	80	21	4	\N	16	DR	\N	19	10.100.255.29	2012-12-20 18:11:16.74127	2012-12-20 18:11:16.74127	sec0 - Database	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI	f	\N	\N	f	\N
383	db204	\N	\N	1	BCF082105K	81	21	4	\N	16	DR	\N	19	10.100.255.30 xscf	2012-12-20 18:12:12.6022	2012-12-20 18:12:12.6022	sec0 - Database	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI	f	\N	\N	f	\N
384	db205	\N	\N	1	BCF0821035	82	21	4	\N	16	DR	\N	19	10.100.255.31 xscf	2012-12-20 18:13:05.314796	2012-12-20 18:13:05.314796	sec0 - Database	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI	f	\N	\N	f	\N
385	deap101	\N	\N	2	0822QAU02C	83	7	2	\N	16	Live	\N	13	10.129.255.35	2012-12-21 11:22:53.108267	2012-12-21 11:22:53.108267	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
386	deap102	\N	\N	2	0821QAU010	84	7	2	\N	16	Live	\N	13	10.129.255.36	2012-12-21 11:23:43.386825	2012-12-21 11:23:43.386825	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
387	deap201	\N	\N	1	0822QAU01A	85	7	2	\N	16	DR	\N	13	Not stated.	2012-12-21 11:24:37.482761	2012-12-21 11:24:37.482761	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
388	deap202	\N	\N	1	0822QAU02F	86	7	2	\N	16	DR	\N	13	Not stated.	2012-12-21 11:25:36.749344	2012-12-21 11:25:36.749344	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
391	decl201	\N	\N	1	0831QBD016	86	15	1	\N	2	DR	\N	13	decl201-con	2012-12-21 11:29:41.415973	2012-12-21 11:29:41.415973	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2222	f	\N	\N	f	\N
393	dedb101	\N	\N	2	BCF083700F	83	21	4	\N	32	Live	\N	13	10.129.255.38	2012-12-21 11:34:42.837723	2012-12-21 11:34:42.837723	Database	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI (2-Offline)	f	\N	\N	f	\N
389	deap301	\N	\N	1	0821QAU013	87	7	2	\N	16	TT	\N	13	Not stated.	2012-12-21 11:26:18.924167	2012-12-21 11:30:19.136936	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
392	decl301	\N	\N	1	0831QBD018	87	15	1	\N	2	TT	\N	13	Not stated.	2012-12-21 11:32:49.053069	2012-12-21 11:32:49.053069	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2222	f	\N	\N	f	\N
390	decl101	\N	\N	2	0834QBD00D	83	15	1	\N	2	Live	\N	13	decl101-con	2012-12-21 11:27:35.230235	2012-12-21 11:32:58.847562	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2222	f	\N	\N	f	\N
394	dedb102	\N	\N	2	BCF083708M	84	21	4	\N	32	Live	\N	13	10.129.255.39	2012-12-21 11:35:18.175327	2012-12-21 11:35:18.175327	Database	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI (2-Offline)	f	\N	\N	f	\N
395	dedb201	\N	\N	1	BCF082200N	85	21	4	\N	64	DR	\N	13		2012-12-21 11:36:27.15731	2012-12-21 11:36:27.15731	Database	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI (2-Offline)	f	\N	\N	f	\N
396	dedb202	\N	\N	1	BCF082202A	86	21	4	\N	64	DR	\N	13		2012-12-21 11:39:26.891326	2012-12-21 11:39:26.891326	Database	Solaris 10	1	\N	DualCore 2.15GHz  UltraSPARC VI (2-Offline)	f	\N	\N	f	\N
397	dedb301	\N	\N	1	0732AN1241	87	14	4	\N	32	TT	\N	13		2012-12-21 11:40:06.394838	2012-12-21 11:40:06.394838	DB	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
398	bcpx202	\N	\N	1	0821QAU01F	49	15	2	\N	4	DR	\N	16	192.168.231.123	2012-12-21 12:01:22.993761	2012-12-21 12:01:22.993761	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
399	bcpx101	\N	\N	2	0822QAU027	47	15	2	\N	4	Live	\N	16	192.168.232.120	2012-12-21 12:02:10.171011	2012-12-21 12:02:10.171011	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
401	bcpx103	\N	\N	2	0822QAU036	47	15	2	\N	4	Live	\N	16	192.168.232.128	2012-12-21 12:03:21.302035	2012-12-21 12:03:21.302035	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 8222	f	\N	\N	f	\N
402	ttap205	\N	\N	1	0617NNN0GT	88	6	1	\N	32	TT	\N	17	10.104.2.112	2012-12-21 12:45:37.342837	2012-12-21 12:45:37.342837	STS/ETS App server	Solaris 10	1	\N	UltraSPARC-T1 (8 Cores) 1.2GHz	f	\N	\N	f	\N
403	ttap206	\N	\N	1	0617NNN09R	88	6	1	\N	32	TT	\N	17	10.104.2.115	2012-12-21 12:46:01.947885	2012-12-21 12:46:01.947885	STS/ETS App server	Solaris 10	1	\N	UltraSPARC-T1 (8 Cores) 1.2GHz	f	\N	\N	f	\N
404	ttsg201	\N	\N	1	TN63740237	89	32	2	\N	8	TT	\N	17	192.168.230.54	2012-12-21 12:52:23.656049	2012-12-21 12:52:23.656049	Swift access - powered off unused?	Solaris 10	1	\N	2 x UltraSPARC-IIIi 1.5GHz	f	\N	\N	f	\N
405	sg405	\N	\N	1	0733TFL03V	33	38	2	\N	16	CR	\N	17	None	2012-12-21 12:54:03.477476	2012-12-21 12:54:03.477476	Swift access	Solaris 10	1	\N	UltraSPARC-IIIi 1.5GHz	f	\N	\N	f	\N
406	sg103	\N	\N	2	BEL0826S8D	51	39	1	\N	16	Live	\N	28	192.168.232.64	2012-12-21 12:58:18.114636	2012-12-21 12:58:18.114636	Swift access	Solaris 10	1	\N	1.2GHz UltraSPARC-T2 (4 cores)	f	\N	\N	f	\N
407	sg104	\N	\N	2	BEL0826S63	50	39	1	\N	16	Live	\N	28	192.168.232.68	2012-12-21 12:58:43.865816	2012-12-21 12:58:43.865816	Swift access	Solaris 10	1	\N	1.2GHz UltraSPARC-T2 (4 cores)	f	\N	\N	f	\N
408	sg105	\N	406	2		51	40	1	\N	16	Live	\N	28	sg103 or sg104	2012-12-21 13:00:17.160077	2012-12-21 13:00:17.160077	Swift access - SAN Boot Image sits on sg103 or sg104	Solaris 10	1	\N	1.2GHz UltraSPARC-T2 (4 cores)	f	\N	\N	f	\N
409	sg203	\N	\N	1	BEL0826SKW	57	39	1	\N	16	DR	\N	28	192.168.231.85	2012-12-21 13:01:35.035354	2012-12-21 13:01:35.035354	Swift access	Solaris 10	1	\N	1.2GHz UltraSPARC-T2 (4 cores)	f	\N	\N	f	\N
410	sg204	\N	\N	1	BEL0826S7Q	90	39	1	\N	16	DR	\N	28	192.168.231.90	2012-12-21 13:01:58.349746	2012-12-21 13:01:58.349746	Swift access	Solaris 10	1	\N	1.2GHz UltraSPARC-T2 (4 cores)	f	\N	\N	f	\N
411	sg205	\N	409	1		57	40	1	\N	16	DR	\N	28	sg203 or sg204	2012-12-21 13:02:45.672563	2012-12-21 13:02:45.672563	Swift access	Solaris 10	1	\N	1.2GHz UltraSPARC-T2 (4 cores)	f	\N	\N	f	\N
412	sg303	\N	\N	1	BEL0825QVC	56	39	1	\N	16	TT	\N	28	sg303-con	2012-12-21 13:03:47.402044	2012-12-21 13:03:47.402044	Swift access	Solaris 10	1	\N	1.2GHz UltraSPARC-T2 (4 cores)	f	\N	\N	f	\N
413	sg304	\N	\N	1	BEL0826SLG	55	39	1	\N	16	TT	\N	28	sg304-con	2012-12-21 13:04:17.062306	2012-12-21 13:04:17.062306	Swift access	Solaris 10	1	\N	1.2GHz UltraSPARC-T2 (4 cores)	f	\N	\N	f	\N
414	sg305	\N	412	1		56	40	1	\N	16	TT	\N	28	sg303 or sg304	2012-12-21 13:05:09.281344	2012-12-21 13:05:32.447648	Swift access SAN boot image sits on SG303 or SG304	Solaris 10	1	1	1.2GHz UltraSPARC-T2 (4 cores)	f	\N	\N	f	\N
415	ecap101	\N	\N	2	0735AL690C	91	17	2	\N	16	Live	\N	1	10.131.4.1	2012-12-21 14:06:15.576942	2012-12-21 14:06:15.576942	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
416	ecap102	\N	\N	2	0735AL690B	92	17	2	\N	16	Live	\N	1	10.131.4.3	2012-12-21 14:07:07.214608	2012-12-21 14:07:07.214608	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
417	ecap103	\N	\N	2	0736AL6958	91	17	2	\N	16	Live	\N	1	10.131.4.13	2012-12-21 14:07:38.854683	2012-12-21 14:07:38.854683	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
418	ecap104	\N	\N	2	0735AL6908	92	17	2	\N	16	Live	\N	1	10.131.4.15	2012-12-21 14:08:08.101996	2012-12-21 14:08:08.101996	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
419	ecap105	\N	\N	2	0643TL407P	91	38	2	\N	8	Live	\N	1	10.131.4.17	2012-12-21 14:09:29.184976	2012-12-21 14:09:29.184976	Application	Solaris 10	1	\N	UltraSPARC-IIIi 1.5GHz	f	\N	\N	f	\N
420	ecap106	\N	\N	2	0647TL30JE	92	38	2	\N	8	Live	\N	1	10.131.4.19	2012-12-21 14:10:05.202597	2012-12-21 14:10:05.202597	Application	Solaris 10	1	\N	UltraSPARC-IIIi 1.5GHz	f	\N	\N	f	\N
422	ecap202	\N	\N	1	0736AL6A83	94	17	2	\N	16	DR	\N	1	10.103.4.3	2012-12-21 14:12:30.535831	2012-12-21 14:12:30.535831	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
421	ecap201	\N	\N	1	0736AL6A82	93	17	2	\N	16	DR	\N	1	10.103.4.1	2012-12-21 14:11:41.028116	2012-12-21 14:12:41.144662	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
423	ecap203	\N	\N	1	0729AL5C3A	93	17	2	\N	16	DR	\N	1	10.103.4.13	2012-12-21 14:13:09.759425	2012-12-21 14:13:09.759425	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
424	ecap204	\N	\N	1	0736AL6A86	94	17	2	\N	16	DR	\N	1	10.103.4.15	2012-12-21 14:14:01.278111	2012-12-21 14:14:01.278111	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
425	ecap205	\N	\N	1	0734TFL0ZU	93	38	2	\N	8	DR	\N	1	10.103.4.17	2012-12-21 14:14:47.546059	2012-12-21 14:16:19.90556	Application	Solaris 10	1	1	UltraSPARC-IIIi 1.5GHz	f	\N	\N	f	\N
426	ecap206	\N	\N	1	0734TFL0ZZ	94	38	2	\N	8	DR	\N	1	10.103.4.19	2012-12-21 14:15:23.313814	2012-12-21 14:16:30.23041	Application	Solaris 10	1	1	UltraSPARC-IIIi 1.5GHz	f	\N	\N	f	\N
302	bcdb601	\N	5	1		63	25	\N	\N	\N	Dev	\N	16		2012-12-05 15:35:06.897563	2012-12-21 14:23:06.152502	DB	Solaris 10	1	\N		f	\N	\N	f	\N
431	ecap305	\N	\N	1	0642TL40CH	95	38	2	\N	8	TT	\N	1	10.104.204.17	2012-12-21 15:48:47.924906	2012-12-21 15:48:47.924906	Application	Solaris 10	1	\N	UltraSPARC-IIIi 1.5GHz	f	\N	\N	f	\N
432	ecap306	\N	\N	1	0725TL301G	33	38	2	\N	8	TT	\N	1	10.104.204.19	2012-12-21 15:49:19.476777	2012-12-21 15:49:19.476777	Application	Solaris 10	1	\N	UltraSPARC-IIIi 1.5GHz	f	\N	\N	f	\N
427	ecap301	\N	\N	1	0736AL6A7F	95	17	2	\N	16	TT	\N	1	10.104.204.1	2012-12-21 15:42:17.531067	2012-12-21 15:49:32.72676	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
428	ecap302	\N	\N	1	0730AL5E02	33	17	2	\N	16	TT	\N	1	10.104.204.3	2012-12-21 15:43:01.055733	2012-12-21 15:49:40.821518	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
429	ecap303	\N	\N	1	0730AL5E04	95	17	2	\N	16	TT	\N	1	10.104.204.13	2012-12-21 15:43:34.852831	2012-12-21 15:49:50.124156	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
430	ecap304	\N	\N	1	0730AL5E03	33	17	2	\N	16	TT	\N	1	10.104.204.15	2012-12-21 15:44:10.199463	2012-12-21 15:50:01.890729	Application	Solaris 10	1	1	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
433	ecap401	\N	\N	1	0722NNN0LP	96	6	1	\N	32	CR	\N	1	10.102.12.1	2012-12-21 15:51:55.936482	2012-12-21 15:52:18.366582	Application	Solaris 10	1	1	UltraSPARC-T1 (8 Cores) 1.2GHz	f	\N	\N	f	\N
434	ecap402	\N	\N	1	0722NNN0VH	96	6	1	\N	32	CR	\N	1	10.102.12.3	2012-12-21 15:52:47.166797	2012-12-21 15:52:47.166797	Application	Solaris 10	1	\N	UltraSPARC-T1 (8 Cores) 1.2GHz	f	\N	\N	f	\N
435	ecap504	\N	\N	1	0736AL6959	97	17	2	\N	16	ELAF	\N	1	10.105.14.134	2012-12-21 15:54:38.864085	2012-12-21 15:54:38.864085	Application	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 2220 (2.6GHz)	f	\N	\N	f	\N
436	ecdb101	\N	\N	2	0731AN1Q44	91	14	4	\N	32	Live	\N	1	10.131.4.5	2012-12-21 15:58:00.870752	2012-12-21 15:58:00.870752	Database	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
437	ecdb102	\N	\N	2		92	14	4	\N	32	Live	\N	1	10.131.4.7	2012-12-21 15:58:27.779395	2012-12-21 15:58:27.779395	Database	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
438	ecdb201	\N	\N	1	0623AN1583	93	14	4	\N	32	DR	\N	1	10.103.4.5	2012-12-21 15:59:10.029202	2012-12-21 15:59:10.029202	Database	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
439	ecdb202	\N	\N	1	0729AN1440	94	14	4	\N	32	DR	\N	1	10.103.4.7	2012-12-21 15:59:39.065274	2012-12-21 15:59:39.065274	Database	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
443	ecdb402	\N	\N	1	0724AN1505	96	14	4	\N	12	CR	\N	1	10.102.12.7	2012-12-21 16:03:09.512712	2012-12-21 16:03:09.512712	Database	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
440	ecdb301	\N	\N	1	0729AN1419	95	14	4	\N	32	TT	\N	1	10.104.204.5	2012-12-21 16:00:27.46609	2012-12-21 16:00:27.46609	Database	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
441	ecdb302	\N	\N	1	0731AN1102	33	14	4	\N	32	TT	\N	1	10.104.204.7	2012-12-21 16:01:13.802611	2012-12-21 16:01:13.802611	Database	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
442	ecdb401	\N	\N	1	0725AN1155	96	14	4	\N	12	CR	\N	1	10.102.12.5	2012-12-21 16:02:26.849892	2012-12-21 16:02:26.849892	Database	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
444	ecdb502	\N	\N	1	0637AN1363	33	14	2	\N	16	ELAF	\N	1	10.105.14.136	2012-12-21 17:12:47.156807	2012-12-21 17:12:47.156807	Database	Solaris 10	1	\N	Dual-Core UltraSPARC-IV+ 1.8Ghz (4 Cores)	f	\N	\N	f	\N
445	ecpx101	\N	\N	2	0721QBL050	91	26	1	\N	2	Live	\N	1	Not stated.	2012-12-21 17:17:30.765259	2012-12-21 17:17:30.765259	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 1220 - 2.2GHz	f	\N	\N	f	\N
446	ecpx102	\N	\N	2	0725QBL00A	92	26	1	\N	2	Live	\N	1	Not stated.	2012-12-21 17:18:05.992182	2012-12-21 17:18:05.992182	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 1220 - 2.2GHz	f	\N	\N	f	\N
447	ecpx103	\N	\N	2	0732QBL071	91	26	1	\N	2	Live	\N	1	Not stated.	2012-12-21 17:18:27.002521	2012-12-21 17:18:27.002521	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 1220 - 2.2GHz	f	\N	\N	f	\N
448	ecpx104	\N	\N	2	0725QBL00A	92	26	1	\N	2	Live	\N	1	Not stated.	2012-12-21 17:19:05.771161	2012-12-21 17:19:05.771161	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 1220 - 2.2GHz	f	\N	\N	f	\N
449	ecpx201	\N	\N	2	0730QBL005	98	26	1	\N	2	DR	\N	1	192.168.231.72	2012-12-21 17:19:58.829133	2012-12-21 17:19:58.829133	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 1220 - 2.2GHz	f	\N	\N	f	\N
450	ecpx202	\N	\N	2	0732QBL075	99	26	1	\N	2	DR	\N	1	192.168.231.73	2012-12-21 17:20:31.447756	2012-12-21 17:20:31.447756	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 1220 - 2.2GHz	f	\N	\N	f	\N
451	ecpx203	\N	\N	1	0732QBL078	93	26	1	\N	2	DR	\N	1	192.168.231.70	2012-12-21 17:21:36.179165	2012-12-21 17:21:36.179165	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 1220 - 2.2GHz	f	\N	\N	f	\N
452	ecpx204	\N	\N	1	0730QBL003	94	26	1	\N	2	DR	\N	1	192.168.231.71	2012-12-21 17:23:01.038743	2012-12-21 17:23:01.038743	Proxy Server	Solaris 10	1	\N	Dual-Core AMD Opteron(tm) Processor 1220 - 2.2GHz	f	\N	\N	f	\N
453	ipap619	\N	\N	1	0731AN1458	95	14	4	\N	16	Dev	\N	23		2012-12-21 17:54:59.079934	2012-12-21 17:54:59.079934	Application	Solaris 10	1	\N	1800MHz UltraSPARC-IV+ (8 Cores)	f	\N	\N	f	\N
363	if102	\N	\N	2	209Q017A	72	11	2	\N	8	Live	\N	19	termserv_deb user: platform	2012-12-07 16:43:41.731881	2012-12-21 18:06:34.455516	Backup/LDAP	Solaris 8	1	1	1200MHz	f	\N	\N	f	\N
454	cm304	\N	150	1		2	24	2	\N	4	Dev	\N	24		2012-12-27 11:36:01.860602	2012-12-27 11:36:01.860602	Git POC can probably be disposed of. Config Services asked.	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
455	cm305	\N	150	1		2	24	2	\N	4	Dev	\N	24		2012-12-27 11:37:22.16088	2012-12-27 11:37:22.16088	Atlassian stash sand box. (Rae Fruen)	RHEL 5	1	\N	vCPU	f	\N	\N	f	\N
456	cmap301	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 12:51:22.640452	2012-12-27 12:51:22.640452	Clearcase upgrade POC	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
470	cmap405	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:33:25.612354	2012-12-27 16:33:25.612354	CM Preprod app	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
471	cmap406	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:33:38.467049	2012-12-27 16:33:38.467049	CM Preprod apache	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
472	cmap407	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:33:55.442447	2012-12-27 16:33:55.442447	CM Preprod crowd	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
473	cmdb401	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:34:16.170958	2012-12-27 16:34:16.170958	CM Preprod DB	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
474	mpap501	\N	150	1		2	24	2	\N	32	UAT	\N	22		2012-12-27 16:36:29.242018	2012-12-27 16:36:29.242018	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
475	mpap601	\N	150	1		2	24	4	\N	32	Dev	\N	22		2012-12-27 16:36:55.180015	2012-12-27 16:36:55.180015	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
476	mpap602	\N	150	1		2	24	4	\N	16	Dev	\N	22		2012-12-27 16:37:14.358757	2012-12-27 16:37:14.358757	Application	Solaris 10	1	\N	vCPU	f	\N	\N	f	\N
457	cmap302	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 12:52:01.696668	2012-12-27 14:49:15.160639	Clearcase upgrade POC	RHEL 5.8	1	\N	vCPU	f	\N	\N	t	2012-12-27
458	cmap303	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 14:50:19.582586	2012-12-27 16:23:08.166147	CM something	RHEL 5.8	1	\N	vCPU	f	\N	\N	t	2012-12-27
459	cmap304	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:23:54.303123	2012-12-27 16:23:54.303123	CM Bamboo	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
460	cmap305	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:24:17.219484	2012-12-27 16:24:21.151571	CM Confluence	RHEL 5.8	1	\N	vCPU	f	\N	\N	t	2012-12-27
461	cmap306	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:25:04.539295	2012-12-27 16:25:09.202846	CM Apache	RHEL 5.8	1	\N	vCPU	f	\N	\N	t	2012-12-27
462	cmap307	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:25:36.262352	2012-12-27 16:25:38.63528	CM Clearvision	RHEL 5.8	1	\N	vCPU	f	\N	\N	t	2012-12-27
463	cmap308	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:25:58.06627	2012-12-27 16:26:01.823151	CM Bamboo	RHEL 5.8	1	\N	vCPU	f	\N	\N	t	2012-12-27
464	cmdb301	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:26:24.340586	2012-12-27 16:26:24.340586	CM Clearvision DB	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
465	apap606	\N	370	1		75	24	2	\N	4	Dev	\N	27		2012-12-27 16:27:56.232467	2012-12-27 16:27:56.232467	Puppet Packaging server	RHEL 6.3	1	\N	vCPU	f	\N	\N	f	\N
466	cmap401	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:31:39.963902	2012-12-27 16:31:39.963902	Clearvision App	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
467	cmap402	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:31:55.821956	2012-12-27 16:31:55.821956	CM Jira	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
468	cmap403	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:32:52.854852	2012-12-27 16:32:52.854852	CM Preprod Crucible	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
469	cmap404	\N	150	1		2	24	4	\N	16	TT	\N	24		2012-12-27 16:33:11.524639	2012-12-27 16:33:11.524639	CM Preprod Bamboo	RHEL 5.8	1	\N	vCPU	f	\N	\N	f	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY users (id, name, email, created_at, updated_at, password_digest, remember_token, admin) FROM stdin;
1	Chris Clayton	chris.does.this@gmail.com	2012-10-18 15:20:00.246168	2012-10-18 15:20:00.246168	$2a$10$7cGnnNr90ruspbdGYNs7AO3gegns/2j2C.FdUlmpwdOwfEnfUfF0G	ju-3eIP8WWrurrKqbIbCmA	t
2	Helen Callaghan	helen.callaghan@vocalink.com	2012-12-03 15:38:56.154878	2012-12-03 15:38:56.154878	$2a$10$21dIIjYFluIhhQU1hefgFeEyqD3jEED6.NccRwQ8mJOlFDZg.loyC	HAvRj7E5dsxd59VLZGRDNg	t
3	Gavin Ward	gavin.ward@vocalink.com	2012-12-03 18:12:02.379094	2012-12-03 18:12:02.379094	$2a$10$tUqjlugsR4SRYeNKg/H2y.wWauzbJbb8EXRxeopMFozzBX5n85lfi	JFARDUnFzwSBDiyokjW-dQ	f
4	Eric Lee	eric.lee@vocalink.com	2012-12-04 10:01:58.943892	2012-12-04 10:01:58.943892	$2a$10$MU5UjNlDbb4irzwoCXPsaOR./XP7YnhoVikZET65meU.KLvF2Cgvq	dNv11A46hLAOgh66lISUBA	f
5	Brendan Morrissey	brendan.morrissey@vocalink.com	2012-12-04 13:20:22.682101	2012-12-04 13:20:22.682101	$2a$10$aKJl4DuFcldLgEgQ8dUcmeac8v/nfQkfwwYFF5Xx2ul4qFUKtjcu2	BT5eUPxC4WwAQz5cita7UA	f
6	Terry Poulter	terry.poulter@vocalink.com	2012-12-14 11:58:15.524139	2012-12-14 11:58:15.524139	$2a$10$TKDea0Ogy0oufiU5KPgqvO4Ss7jUayD2dMS7N3uilfywuFUlAmo1K	RyndRJ2xTAvDYqbnshUFow	t
\.


--
-- Data for Name: vclusters; Type: TABLE DATA; Schema: public; Owner: unix_web
--

COPY vclusters (id, name, comment, created_at, updated_at) FROM stdin;
\.


--
-- Name: changes_pkey; Type: CONSTRAINT; Schema: public; Owner: unix_web; Tablespace: 
--

ALTER TABLE ONLY changes
    ADD CONSTRAINT changes_pkey PRIMARY KEY (id);


--
-- Name: cpus_pkey; Type: CONSTRAINT; Schema: public; Owner: unix_web; Tablespace: 
--

ALTER TABLE ONLY cpus
    ADD CONSTRAINT cpus_pkey PRIMARY KEY (id);


--
-- Name: datacenters_pkey; Type: CONSTRAINT; Schema: public; Owner: unix_web; Tablespace: 
--

ALTER TABLE ONLY datacenters
    ADD CONSTRAINT datacenters_pkey PRIMARY KEY (id);


--
-- Name: operating_systems_pkey; Type: CONSTRAINT; Schema: public; Owner: unix_web; Tablespace: 
--

ALTER TABLE ONLY operating_systems
    ADD CONSTRAINT operating_systems_pkey PRIMARY KEY (id);


--
-- Name: projects_pkey; Type: CONSTRAINT; Schema: public; Owner: unix_web; Tablespace: 
--

ALTER TABLE ONLY projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: server_models_pkey; Type: CONSTRAINT; Schema: public; Owner: unix_web; Tablespace: 
--

ALTER TABLE ONLY server_models
    ADD CONSTRAINT server_models_pkey PRIMARY KEY (id);


--
-- Name: server_racks_pkey; Type: CONSTRAINT; Schema: public; Owner: unix_web; Tablespace: 
--

ALTER TABLE ONLY server_racks
    ADD CONSTRAINT server_racks_pkey PRIMARY KEY (id);


--
-- Name: servers_pkey; Type: CONSTRAINT; Schema: public; Owner: unix_web; Tablespace: 
--

ALTER TABLE ONLY servers
    ADD CONSTRAINT servers_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: unix_web; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vclusters_pkey; Type: CONSTRAINT; Schema: public; Owner: unix_web; Tablespace: 
--

ALTER TABLE ONLY vclusters
    ADD CONSTRAINT vclusters_pkey PRIMARY KEY (id);


--
-- Name: index_servers_on_name; Type: INDEX; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE INDEX index_servers_on_name ON servers USING btree (name);


--
-- Name: index_servers_on_parent_id; Type: INDEX; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE INDEX index_servers_on_parent_id ON servers USING btree (parent_id);


--
-- Name: index_servers_on_project_id; Type: INDEX; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE INDEX index_servers_on_project_id ON servers USING btree (project_id);


--
-- Name: index_servers_on_server_rack_id; Type: INDEX; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE INDEX index_servers_on_server_rack_id ON servers USING btree (server_rack_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (email);


--
-- Name: index_users_on_remember_token; Type: INDEX; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE INDEX index_users_on_remember_token ON users USING btree (remember_token);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: unix_web; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

